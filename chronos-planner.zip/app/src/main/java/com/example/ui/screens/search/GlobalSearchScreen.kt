package com.example.ui.screens.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.common.ExecutiveCard
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.theme.RoseViolet
import com.example.ui.viewmodel.PlannerViewModel

@Composable
fun GlobalSearchScreen(
    viewModel: PlannerViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val events by viewModel.events.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val notes by viewModel.notes.collectAsState()

    val matchedEvents = if (query.isBlank()) emptyList() else events.filter {
        it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true) || it.location.contains(query, ignoreCase = true)
    }

    val matchedTasks = if (query.isBlank()) emptyList() else tasks.filter {
        it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true)
    }

    val matchedNotes = if (query.isBlank()) emptyList() else notes.filter {
        it.title.contains(query, ignoreCase = true) || it.content.contains(query, ignoreCase = true) || it.tags.contains(query, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search events, tasks, notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.weight(1f).testTag("input_global_search")
                )

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close search")
                }
            }
        }

        if (query.isNotBlank()) {
            item {
                Text(
                    text = "Results for \"$query\" (${matchedEvents.size + matchedTasks.size + matchedNotes.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (matchedEvents.isNotEmpty()) {
                item {
                    Text("Events (${matchedEvents.size})", style = MaterialTheme.typography.labelMedium, color = ElectricIndigo, fontWeight = FontWeight.Bold)
                }
                items(matchedEvents) { event ->
                    ExecutiveCard(onClick = { viewModel.openEditEventDialog(event) }) {
                        Column {
                            Text(text = event.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text(text = "${event.startDate} • ${event.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (matchedTasks.isNotEmpty()) {
                item {
                    Text("Tasks (${matchedTasks.size})", style = MaterialTheme.typography.labelMedium, color = EmeraldTeal, fontWeight = FontWeight.Bold)
                }
                items(matchedTasks) { task ->
                    ExecutiveCard(onClick = { viewModel.openEditTaskDialog(task) }) {
                        Column {
                            Text(text = task.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text(text = "Priority: ${task.priority} • Due: ${task.dueDate ?: "None"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (matchedNotes.isNotEmpty()) {
                item {
                    Text("Notes (${matchedNotes.size})", style = MaterialTheme.typography.labelMedium, color = RoseViolet, fontWeight = FontWeight.Bold)
                }
                items(matchedNotes) { note ->
                    ExecutiveCard {
                        Column {
                            Text(text = note.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text(text = note.content, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

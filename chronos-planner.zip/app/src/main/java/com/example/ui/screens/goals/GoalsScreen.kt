package com.example.ui.screens.goals

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.GoalEntity
import com.example.ui.common.CategoryPill
import com.example.ui.common.ExecutiveCard
import com.example.ui.theme.AmberFlare
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.theme.RoseViolet
import com.example.ui.viewmodel.PlannerViewModel
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun GoalsScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val goals by viewModel.goals.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val habitsWithStats by viewModel.habitsWithStats.collectAsState()

    val completedTasks = tasks.count { it.isCompleted }
    val totalTasks = tasks.size
    val habitRate = if (habitsWithStats.isNotEmpty()) {
        (habitsWithStats.count { it.isCompletedToday } * 100 / habitsWithStats.size)
    } else 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Goals & Analytics",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Executive velocity & milestone tracking",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { viewModel.openNewGoalDialog() },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_add_goal")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Goal")
                }
            }
        }

        // Productivity Statistics Overview Card
        item {
            ExecutiveCard(borderColor = ElectricIndigo.copy(alpha = 0.35f)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Productivity Metric Matrix",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBlock(label = "Tasks Completed", value = "$completedTasks / $totalTasks", color = EmeraldTeal)
                        MetricBlock(label = "Habit Streak Rate", value = "$habitRate%", color = AmberFlare)
                        MetricBlock(label = "Focus Velocity", value = "94%", color = ElectricIndigo)
                    }

                    // Weekly Productivity Trend Visual Bars
                    Text("Weekly Output Trend", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        val days = listOf("M" to 0.7f, "T" to 0.85f, "W" to 0.6f, "T" to 0.95f, "F" to 0.8f, "S" to 0.4f, "S" to 0.65f)
                        days.forEach { (d, ratio) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height((40 * ratio).dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (ratio > 0.8f) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = d, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // Active Goals
        item {
            Text(
                text = "Target Goals (${goals.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (goals.isEmpty()) {
            item {
                ExecutiveCard {
                    Text("No goals created yet. Tap + to define milestones.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(goals) { goal ->
                GoalItemCard(
                    goal = goal,
                    onToggleMilestone = { updatedGoal -> viewModel.saveGoal(updatedGoal) },
                    onDelete = { viewModel.deleteGoal(goal) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun MetricBlock(label: String, value: String, color: Color) {
    Column {
        Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GoalItemCard(
    goal: GoalEntity,
    onToggleMilestone: (GoalEntity) -> Unit,
    onDelete: () -> Unit
) {
    ExecutiveCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = goal.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Target: ${goal.targetDate} • ${goal.type.replace("_", " ")}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LinearProgressIndicator(
                    progress = { goal.progressPercent / 100f },
                    modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (goal.progressPercent == 100) EmeraldTeal else ElectricIndigo,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Text(
                    text = "${goal.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Milestones Checklist
            val milestones = remember(goal.milestonesJson) {
                val list = mutableListOf<Triple<Int, String, Boolean>>()
                try {
                    val array = JSONArray(goal.milestonesJson)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        list.add(Triple(i, obj.optString("title", "Milestone"), obj.optBoolean("isDone", false)))
                    }
                } catch (_: Exception) {}
                list
            }

            if (milestones.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    milestones.forEach { (index, mTitle, isDone) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    try {
                                        val array = JSONArray(goal.milestonesJson)
                                        val obj = array.getJSONObject(index)
                                        obj.put("isDone", !isDone)
                                        var doneCount = 0
                                        for (k in 0 until array.length()) {
                                            if (array.getJSONObject(k).optBoolean("isDone", false)) doneCount++
                                        }
                                        val newProgress = (doneCount * 100) / array.length()
                                        onToggleMilestone(goal.copy(milestonesJson = array.toString(), progressPercent = newProgress))
                                    } catch (_: Exception) {}
                                }
                        ) {
                            Icon(
                                imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isDone) EmeraldTeal else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = mTitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

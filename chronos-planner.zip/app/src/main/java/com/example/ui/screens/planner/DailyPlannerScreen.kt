package com.example.ui.screens.planner

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.EventEntity
import com.example.data.entity.TaskEntity
import com.example.ui.common.ExecutiveCard
import com.example.ui.common.PriorityBadge
import com.example.ui.theme.AmberFlare
import com.example.ui.theme.CoralUrgent
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.viewmodel.PlannerViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun DailyPlannerScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val events by viewModel.events.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val preferences by viewModel.userPreferences.collectAsState()

    val dateStr = selectedDate.toString()
    val dayEvents = events.filter { it.startDate == dateStr || (!it.isAllDay && it.startDate <= dateStr && it.endDate >= dateStr) }
    val dayTasks = tasks.filter { it.dueDate == dateStr }

    // Calculate busy minutes vs free minutes in working hours (e.g. 9am to 6pm = 9 hours = 540 min)
    val workStartMin = preferences.workDayStartHour * 60
    val workEndMin = preferences.workDayEndHour * 60
    val totalWorkMinutes = (workEndMin - workStartMin).coerceAtLeast(60)

    val allocatedMinutes = dayEvents.filter { !it.isAllDay }.sumOf { (it.endMinutes - it.startMinutes).coerceAtLeast(0) }
    val freeMinutes = (totalWorkMinutes - allocatedMinutes).coerceAtLeast(0)
    val loadRatio = (allocatedMinutes.toFloat() / totalWorkMinutes).coerceIn(0f, 1f)

    val currentNow = LocalTime.now()
    val currentNowMinutes = currentNow.hour * 60 + currentNow.minute
    val isToday = selectedDate == LocalDate.now()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Navigation Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.selectDate(selectedDate.minusDays(1)) }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Prev day")
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = selectedDate.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault())),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = selectedDate.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.getDefault())),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = { viewModel.selectDate(selectedDate.plusDays(1)) }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next day")
                }
            }
        }

        // Daily Time Load Indicator (Allocated vs Free)
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Time Allocation",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${allocatedMinutes / 60}h ${allocatedMinutes % 60}m Allocated • ${freeMinutes / 60}h ${freeMinutes % 60}m Free",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    LinearProgressIndicator(
                        progress = { loadRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (loadRatio > 0.85f) CoralUrgent else ElectricIndigo,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Start: ${preferences.workDayStartHour}:00",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "End: ${preferences.workDayEndHour}:00",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Unscheduled / Pending Tasks for this Day
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Day Tasks (${dayTasks.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                TextButton(
                    onClick = {
                        // Move unfinished tasks to tomorrow
                        val tomorrow = selectedDate.plusDays(1).toString()
                        dayTasks.filter { !it.isCompleted }.forEach {
                            viewModel.saveTask(it.copy(dueDate = tomorrow))
                        }
                        viewModel.showSnack("Moved unfinished tasks to tomorrow")
                    }
                ) {
                    Text("Defer to Tomorrow", style = MaterialTheme.typography.labelSmall, color = ElectricIndigo)
                }
            }
        }

        if (dayTasks.isEmpty()) {
            item {
                ExecutiveCard {
                    Text("No tasks assigned to this date.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            items(dayTasks) { task ->
                ExecutiveCard(onClick = { viewModel.openEditTaskDialog(task) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { viewModel.toggleTask(task) }) {
                            Icon(
                                imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                contentDescription = "Complete",
                                tint = if (task.isCompleted) EmeraldTeal else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Est: ${task.estimatedMinutes}m • ${task.category}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        PriorityBadge(priority = task.priority)

                        Spacer(modifier = Modifier.width(6.dp))

                        // Quick Schedule to Calendar Button
                        Button(
                            onClick = { viewModel.convertTaskToEvent(task, 600) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo.copy(alpha = 0.2f)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Block", fontSize = 11.sp, color = ElectricIndigo, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Time-Blocking Timeline (06:00 to 23:00)
        item {
            Text(
                text = "Time-Block Timeline",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        val hours = (6..23).toList()
        items(hours) { hour ->
            val slotStart = hour * 60
            val slotEnd = (hour + 1) * 60
            val slotEvents = dayEvents.filter { !it.isAllDay && it.startMinutes < slotEnd && it.endMinutes > slotStart }
            val hasOverlap = slotEvents.size > 1
            val isCurrentHour = isToday && currentNow.hour == hour

            Column(modifier = Modifier.fillMaxWidth()) {
                // If current time falls inside this hour, render red indicator laser
                if (isToday && currentNow.hour == hour) {
                    val minuteOffsetRatio = currentNow.minute / 60f
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(CoralUrgent)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(2.dp)
                                .background(CoralUrgent)
                        )
                        Text(
                            text = String.format("%02d:%02d NOW", currentNow.hour, currentNow.minute),
                            style = MaterialTheme.typography.labelSmall,
                            color = CoralUrgent,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(68.dp)
                        .clickable { viewModel.openNewEventDialog(selectedDate, slotStart) }
                ) {
                    // Time Label
                    Text(
                        text = if (preferences.is24HourFormat) String.format("%02d:00", hour) else {
                            val h = if (hour % 12 == 0) 12 else hour % 12
                            val p = if (hour >= 12) "PM" else "AM"
                            "$h $p"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isCurrentHour) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isCurrentHour) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.width(52.dp)
                    )

                    // Time Block Container
                    Surface(
                        modifier = Modifier.weight(1f).height(64.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = if (slotEvents.isNotEmpty()) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface.copy(alpha = 0.4f),
                        border = BorderStroke(
                            1.dp,
                            if (hasOverlap) CoralUrgent else if (isCurrentHour) ElectricIndigo else MaterialTheme.colorScheme.outlineVariant
                        )
                    ) {
                        if (slotEvents.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = "+ Tap to block time",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                                )
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                slotEvents.forEach { ev ->
                                    Surface(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { viewModel.openEditEventDialog(ev) },
                                        color = Color(ev.colorHex),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(6.dp),
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (hasOverlap) {
                                                    Icon(
                                                        imageVector = Icons.Default.Warning,
                                                        contentDescription = "Conflict",
                                                        tint = Color.White,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                }
                                                Text(
                                                    text = ev.title,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.White,
                                                    maxLines = 1
                                                )
                                            }
                                            Text(
                                                text = "${ev.startMinutes / 60}:${String.format("%02d", ev.startMinutes % 60)} - ${ev.endMinutes / 60}:${String.format("%02d", ev.endMinutes % 60)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.White.copy(alpha = 0.85f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

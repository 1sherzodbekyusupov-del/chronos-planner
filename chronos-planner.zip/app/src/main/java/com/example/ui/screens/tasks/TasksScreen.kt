package com.example.ui.screens.tasks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.TaskEntity
import com.example.ui.common.CategoryPill
import com.example.ui.common.ExecutiveCard
import com.example.ui.common.PriorityBadge
import com.example.ui.common.SubtaskItem
import com.example.ui.theme.CoralUrgent
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.viewmodel.PlannerViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

enum class TaskFilter {
    INBOX,
    TODAY,
    TOMORROW,
    UPCOMING,
    OVERDUE,
    COMPLETED
}

@Composable
fun TasksScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.tasks.collectAsState()
    var selectedFilter by remember { mutableStateOf(TaskFilter.TODAY) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val todayStr = LocalDate.now().toString()
    val tomorrowStr = LocalDate.now().plusDays(1).toString()

    val filteredTasks = tasks.filter { task ->
        val matchesSearch = searchQuery.isBlank() || task.title.contains(searchQuery, ignoreCase = true) || task.description.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == null || task.category.equals(selectedCategory, ignoreCase = true)

        val matchesFilter = when (selectedFilter) {
            TaskFilter.INBOX -> task.dueDate == null && !task.isCompleted
            TaskFilter.TODAY -> task.dueDate == todayStr && !task.isCompleted
            TaskFilter.TOMORROW -> task.dueDate == tomorrowStr && !task.isCompleted
            TaskFilter.UPCOMING -> task.dueDate != null && task.dueDate > todayStr && !task.isCompleted
            TaskFilter.OVERDUE -> task.dueDate != null && task.dueDate < todayStr && !task.isCompleted
            TaskFilter.COMPLETED -> task.isCompleted
        }

        matchesSearch && matchesCategory && matchesFilter
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search & Add Task Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search tasks...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { viewModel.openNewTaskDialog() },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_add_task")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add")
                }
            }
        }

        // Filter Pills: Inbox, Today, Tomorrow, Upcoming, Overdue, Completed
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TaskFilter.entries) { filter ->
                    val isSelected = selectedFilter == filter
                    val count = when (filter) {
                        TaskFilter.INBOX -> tasks.count { it.dueDate == null && !it.isCompleted }
                        TaskFilter.TODAY -> tasks.count { it.dueDate == todayStr && !it.isCompleted }
                        TaskFilter.TOMORROW -> tasks.count { it.dueDate == tomorrowStr && !it.isCompleted }
                        TaskFilter.UPCOMING -> tasks.count { it.dueDate != null && it.dueDate > todayStr && !it.isCompleted }
                        TaskFilter.OVERDUE -> tasks.count { it.dueDate != null && it.dueDate < todayStr && !it.isCompleted }
                        TaskFilter.COMPLETED -> tasks.count { it.isCompleted }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) ElectricIndigo else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (isSelected) ElectricIndigo else MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .clickable { selectedFilter = filter }
                            .testTag("filter_task_${filter.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = filter.name.lowercase().replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                            if (count > 0) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isSelected) Color.White.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = count.toString(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Category Filter Row
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(null to "All", "Work" to "Work", "Personal" to "Personal", "Deep Work" to "Deep Work").forEach { (cat, label) ->
                    CategoryPill(
                        category = label,
                        isSelected = selectedCategory == cat,
                        onClick = { selectedCategory = cat }
                    )
                }
            }
        }

        // Task Items List
        if (filteredTasks.isEmpty()) {
            item {
                ExecutiveCard {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No tasks found in ${selectedFilter.name.lowercase()}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredTasks) { task ->
                TaskListItemCard(
                    task = task,
                    onToggle = { viewModel.toggleTask(task) },
                    onEdit = { viewModel.openEditTaskDialog(task) },
                    onSchedule = { viewModel.convertTaskToEvent(task, 600) },
                    onDelete = { viewModel.deleteTask(task) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun TaskListItemCard(
    task: TaskEntity,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onSchedule: () -> Unit,
    onDelete: () -> Unit
) {
    ExecutiveCard(onClick = onEdit) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(36.dp).testTag("btn_task_toggle_${task.id}")
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                        contentDescription = "Toggle",
                        tint = if (task.isCompleted) EmeraldTeal else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                        color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                    if (task.description.isNotBlank()) {
                        Text(
                            text = task.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                    }
                }

                PriorityBadge(priority = task.priority)
            }

            // Subtasks preview & quick actions
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 42.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryPill(category = task.category)

                    if (task.dueDate != null) {
                        Text(
                            text = "Due ${task.dueDate}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (task.dueDate < LocalDate.now().toString() && !task.isCompleted) CoralUrgent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onSchedule, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = "Schedule", tint = ElectricIndigo)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.EventEntity
import com.example.data.entity.GoalEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.HabitLogEntity
import com.example.data.entity.NoteEntity
import com.example.data.entity.RoutineTemplateEntity
import com.example.data.entity.TaskEntity
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.HabitWithStats
import com.example.data.repository.PlannerRepository
import com.example.receiver.AlarmScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class ScreenTab {
    HOME,
    CALENDAR,
    PLANNER,
    TASKS,
    HABITS,
    ROUTINES,
    GOALS,
    NOTES,
    SETTINGS
}

enum class CalendarViewMode {
    DAY,
    WEEK,
    MONTH,
    YEAR,
    AGENDA
}

data class ConflictWarning(
    val conflictingEvents: List<EventEntity>,
    val pendingEvent: EventEntity? = null
)

class PlannerViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val alarmScheduler = AlarmScheduler(application)
    val repository = PlannerRepository(database.plannerDao(), alarmScheduler)
    val preferencesRepository = UserPreferencesRepository(application)

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    // Current Screen & Selected Date
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val _calendarViewMode = MutableStateFlow(CalendarViewMode.MONTH)
    val calendarViewMode: StateFlow<CalendarViewMode> = _calendarViewMode.asStateFlow()

    // Global Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Room Flows
    val events: StateFlow<List<EventEntity>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habits: StateFlow<List<HabitEntity>> = repository.allHabits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val habitLogs: StateFlow<List<HabitLogEntity>> = repository.allHabitLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val routines: StateFlow<List<RoutineTemplateEntity>> = repository.allRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val goals: StateFlow<List<GoalEntity>> = repository.allGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<NoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dialog & Conflict States
    private val _eventToEdit = MutableStateFlow<EventEntity?>(null)
    val eventToEdit: StateFlow<EventEntity?> = _eventToEdit.asStateFlow()

    private val _showEventDialog = MutableStateFlow(false)
    val showEventDialog: StateFlow<Boolean> = _showEventDialog.asStateFlow()

    private val _taskToEdit = MutableStateFlow<TaskEntity?>(null)
    val taskToEdit: StateFlow<TaskEntity?> = _taskToEdit.asStateFlow()

    private val _showTaskDialog = MutableStateFlow(false)
    val showTaskDialog: StateFlow<Boolean> = _showTaskDialog.asStateFlow()

    private val _habitToEdit = MutableStateFlow<HabitEntity?>(null)
    val habitToEdit: StateFlow<HabitEntity?> = _habitToEdit.asStateFlow()

    private val _showHabitDialog = MutableStateFlow(false)
    val showHabitDialog: StateFlow<Boolean> = _showHabitDialog.asStateFlow()

    private val _showRoutineDialog = MutableStateFlow(false)
    val showRoutineDialog: StateFlow<Boolean> = _showRoutineDialog.asStateFlow()

    private val _showApplyRoutineDialog = MutableStateFlow<RoutineTemplateEntity?>(null)
    val showApplyRoutineDialog: StateFlow<RoutineTemplateEntity?> = _showApplyRoutineDialog.asStateFlow()

    private val _showGoalDialog = MutableStateFlow(false)
    val showGoalDialog: StateFlow<Boolean> = _showGoalDialog.asStateFlow()

    private val _goalToEdit = MutableStateFlow<GoalEntity?>(null)
    val goalToEdit: StateFlow<GoalEntity?> = _goalToEdit.asStateFlow()

    private val _showNoteDialog = MutableStateFlow(false)
    val showNoteDialog: StateFlow<Boolean> = _showNoteDialog.asStateFlow()

    private val _noteToEdit = MutableStateFlow<NoteEntity?>(null)
    val noteToEdit: StateFlow<NoteEntity?> = _noteToEdit.asStateFlow()

    private val _conflictWarning = MutableStateFlow<ConflictWarning?>(null)
    val conflictWarning: StateFlow<ConflictWarning?> = _conflictWarning.asStateFlow()

    private val _snackMessage = MutableStateFlow<String?>(null)
    val snackMessage: StateFlow<String?> = _snackMessage.asStateFlow()

    // Derived: Habits with Streaks
    val habitsWithStats: StateFlow<List<HabitWithStats>> = combine(
        habits,
        habitLogs,
        _selectedDate
    ) { habitList, logs, currentDate ->
        val dateStr = currentDate.toString()
        val logsByHabit = logs.groupBy { it.habitId }

        habitList.map { habit ->
            val habitLogsList = logsByHabit[habit.id] ?: emptyList()
            val historyDates = habitLogsList.map { it.date }.toSet()
            val isCompletedToday = historyDates.contains(dateStr)

            // Calculate current streak
            var streak = 0
            var checkDate = if (isCompletedToday) currentDate else currentDate.minusDays(1)
            while (historyDates.contains(checkDate.toString())) {
                streak++
                checkDate = checkDate.minusDays(1)
            }

            // Calculate best streak
            var maxStreak = 0
            var currentRun = 0
            val sortedDates = historyDates.mapNotNull {
                try { LocalDate.parse(it) } catch (_: Exception) { null }
            }.sorted()

            for (i in sortedDates.indices) {
                if (i == 0) {
                    currentRun = 1
                } else {
                    if (sortedDates[i] == sortedDates[i - 1].plusDays(1)) {
                        currentRun++
                    } else if (sortedDates[i] != sortedDates[i - 1]) {
                        currentRun = 1
                    }
                }
                if (currentRun > maxStreak) maxStreak = currentRun
            }

            // Completions this week
            val startOfWeek = currentDate.minusDays(currentDate.dayOfWeek.value.toLong() - 1)
            val endOfWeek = startOfWeek.plusDays(6)
            val thisWeekCount = habitLogsList.count {
                try {
                    val d = LocalDate.parse(it.date)
                    !d.isBefore(startOfWeek) && !d.isAfter(endOfWeek)
                } catch (_: Exception) { false }
            }

            HabitWithStats(
                habit = habit,
                isCompletedToday = isCompletedToday,
                currentStreak = streak,
                bestStreak = maxOf(streak, maxStreak),
                completionCountThisWeek = thisWeekCount,
                historyDates = historyDates
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
    }

    fun setCalendarViewMode(mode: CalendarViewMode) {
        _calendarViewMode.value = mode
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearSnackMessage() {
        _snackMessage.value = null
    }

    fun showSnack(msg: String) {
        _snackMessage.value = msg
    }

    // Events Operations
    fun openNewEventDialog(initialDate: LocalDate? = null, initialStartMinutes: Int = 540) {
        _eventToEdit.value = EventEntity(
            title = "",
            startDate = (initialDate ?: _selectedDate.value).toString(),
            endDate = (initialDate ?: _selectedDate.value).toString(),
            startMinutes = initialStartMinutes,
            endMinutes = initialStartMinutes + 60,
            category = "Work"
        )
        _showEventDialog.value = true
    }

    fun openEditEventDialog(event: EventEntity) {
        _eventToEdit.value = event
        _showEventDialog.value = true
    }

    fun dismissEventDialog() {
        _showEventDialog.value = false
        _eventToEdit.value = null
        _conflictWarning.value = null
    }

    fun saveEvent(event: EventEntity, bypassConflictCheck: Boolean = false) {
        viewModelScope.launch {
            if (!bypassConflictCheck && !event.isAllDay) {
                val conflicts = repository.findConflicts(
                    event.startDate,
                    event.startMinutes,
                    event.endMinutes,
                    excludeId = if (event.id != 0L) event.id else null
                )
                if (conflicts.isNotEmpty()) {
                    _conflictWarning.value = ConflictWarning(conflictingEvents = conflicts, pendingEvent = event)
                    return@launch
                }
            }

            if (event.id == 0L) {
                repository.insertEvent(event)
                showSnack("Event scheduled")
            } else {
                repository.updateEvent(event)
                showSnack("Event updated")
            }
            dismissEventDialog()
        }
    }

    fun deleteEvent(event: EventEntity) {
        viewModelScope.launch {
            repository.deleteEvent(event)
            showSnack("Event removed")
        }
    }

    fun duplicateEvent(event: EventEntity) {
        viewModelScope.launch {
            repository.duplicateEvent(event)
            showSnack("Event duplicated")
        }
    }

    // Tasks Operations
    fun openNewTaskDialog(initialDate: LocalDate? = null) {
        _taskToEdit.value = TaskEntity(
            title = "",
            dueDate = (initialDate ?: _selectedDate.value).toString(),
            dueMinutes = 600,
            priority = "MEDIUM",
            category = "Work"
        )
        _showTaskDialog.value = true
    }

    fun openEditTaskDialog(task: TaskEntity) {
        _taskToEdit.value = task
        _showTaskDialog.value = true
    }

    fun dismissTaskDialog() {
        _showTaskDialog.value = false
        _taskToEdit.value = null
    }

    fun saveTask(task: TaskEntity) {
        viewModelScope.launch {
            if (task.id == 0L) {
                repository.insertTask(task)
                showSnack("Task created")
            } else {
                repository.updateTask(task)
                showSnack("Task updated")
            }
            dismissTaskDialog()
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(task)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
            showSnack("Task deleted")
        }
    }

    fun convertTaskToEvent(task: TaskEntity, startMinutes: Int = 600) {
        viewModelScope.launch {
            val date = task.dueDate ?: _selectedDate.value.toString()
            repository.convertTaskToEvent(task, date, startMinutes, task.estimatedMinutes)
            showSnack("Scheduled to calendar")
        }
    }

    // Habit Operations
    fun openNewHabitDialog() {
        _habitToEdit.value = HabitEntity(title = "", category = "Health & Habits")
        _showHabitDialog.value = true
    }

    fun dismissHabitDialog() {
        _showHabitDialog.value = false
        _habitToEdit.value = null
    }

    fun saveHabit(habit: HabitEntity) {
        viewModelScope.launch {
            if (habit.id == 0L) {
                repository.insertHabit(habit)
                showSnack("Habit added")
            } else {
                repository.updateHabit(habit)
                showSnack("Habit updated")
            }
            dismissHabitDialog()
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.deleteHabit(habit)
            showSnack("Habit removed")
        }
    }

    fun toggleHabitToday(habitWithStats: HabitWithStats, targetDate: LocalDate = _selectedDate.value) {
        viewModelScope.launch {
            repository.toggleHabitForDate(
                habitWithStats.habit.id,
                targetDate.toString(),
                habitWithStats.isCompletedToday
            )
        }
    }

    // Routines Operations
    fun openNewRoutineDialog() {
        _showRoutineDialog.value = true
    }

    fun dismissRoutineDialog() {
        _showRoutineDialog.value = false
    }

    fun saveRoutine(routine: RoutineTemplateEntity) {
        viewModelScope.launch {
            if (routine.id == 0L) {
                repository.insertRoutine(routine)
                showSnack("Routine saved")
            } else {
                repository.updateRoutine(routine)
                showSnack("Routine updated")
            }
            dismissRoutineDialog()
        }
    }

    fun deleteRoutine(routine: RoutineTemplateEntity) {
        viewModelScope.launch {
            repository.deleteRoutine(routine)
            showSnack("Routine deleted")
        }
    }

    fun promptApplyRoutine(routine: RoutineTemplateEntity) {
        _showApplyRoutineDialog.value = routine
    }

    fun dismissApplyRoutine() {
        _showApplyRoutineDialog.value = null
    }

    fun applyRoutine(routine: RoutineTemplateEntity, date: LocalDate, baseMinutes: Int, conflictStrategy: String) {
        viewModelScope.launch {
            val count = repository.applyRoutineToDate(routine, date.toString(), baseMinutes, conflictStrategy)
            dismissApplyRoutine()
            showSnack("Added $count events from ${routine.name}")
        }
    }

    // Goals Operations
    fun openNewGoalDialog() {
        _goalToEdit.value = GoalEntity(
            title = "",
            targetDate = _selectedDate.value.plusWeeks(2).toString(),
            type = "MONTHLY",
            category = "Work"
        )
        _showGoalDialog.value = true
    }

    fun dismissGoalDialog() {
        _showGoalDialog.value = false
        _goalToEdit.value = null
    }

    fun saveGoal(goal: GoalEntity) {
        viewModelScope.launch {
            if (goal.id == 0L) {
                repository.insertGoal(goal)
                showSnack("Goal created")
            } else {
                repository.updateGoal(goal)
                showSnack("Goal updated")
            }
            dismissGoalDialog()
        }
    }

    fun deleteGoal(goal: GoalEntity) {
        viewModelScope.launch {
            repository.deleteGoal(goal)
            showSnack("Goal deleted")
        }
    }

    // Notes Operations
    fun openNewNoteDialog() {
        _noteToEdit.value = NoteEntity(title = "", content = "")
        _showNoteDialog.value = true
    }

    fun dismissNoteDialog() {
        _showNoteDialog.value = false
        _noteToEdit.value = null
    }

    fun saveNote(note: NoteEntity) {
        viewModelScope.launch {
            if (note.id == 0L) {
                repository.insertNote(note)
                showSnack("Note captured")
            } else {
                repository.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
                showSnack("Note updated")
            }
            dismissNoteDialog()
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
            showSnack("Note deleted")
        }
    }

    fun convertNoteToTask(note: NoteEntity) {
        viewModelScope.launch {
            val task = TaskEntity(
                title = note.title.ifEmpty { "Note Task" },
                description = note.content,
                dueDate = _selectedDate.value.toString(),
                priority = "MEDIUM",
                category = "Personal"
            )
            repository.insertTask(task)
            showSnack("Converted note to task")
        }
    }

    // Helpers
    fun formatMinutes(minutes: Int, is24Hour: Boolean): String {
        if (minutes < 0) return "All day"
        val hours = minutes / 60
        val mins = minutes % 60
        return if (is24Hour) {
            String.format(Locale.getDefault(), "%02d:%02d", hours, mins)
        } else {
            val period = if (hours >= 12) "PM" else "AM"
            val displayHour = when (hours % 12) {
                0 -> 12
                else -> hours % 12
            }
            String.format(Locale.getDefault(), "%d:%02d %s", displayHour, mins, period)
        }
    }
}

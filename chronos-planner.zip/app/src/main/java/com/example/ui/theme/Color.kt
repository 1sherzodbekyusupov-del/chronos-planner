package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Executive Precision Palette
val CanvasBase = Color(0xFF0B0F19)
val SurfaceContainerLowest = Color(0xFF0A0E18)
val SurfaceContainerLow = Color(0xFF171B26)
val SurfaceContainer = Color(0xFF161E31)
val SurfaceContainerHigh = Color(0xFF1E293B)
val SurfaceContainerHighest = Color(0xFF262A35)
val SurfaceBright = Color(0xFF353944)

val OnSurfacePrimary = Color(0xFFDFE2F1)
val OnSurfaceSecondary = Color(0xFF94A3B8)
val OnSurfaceMuted = Color(0xFF64748B)

val OutlineDark = Color(0xFF2A334A)
val OutlineVariantDark = Color(0x1FFFFFFF)

// Brand & Semantic Categories
val ElectricIndigo = Color(0xFF6366F1)
val ElectricIndigoLight = Color(0xFFC0C1FF)
val ElectricIndigoContainer = Color(0xFF4338CA)

val EmeraldTeal = Color(0xFF10B981)
val EmeraldTealLight = Color(0xFF6EE7B7)
val EmeraldTealContainer = Color(0xFF065F46)

val AmberFlare = Color(0xFFF59E0B)
val AmberFlareLight = Color(0xFFFCD34D)
val AmberFlareContainer = Color(0xFF78350F)

val RoseViolet = Color(0xFF8B5CF6)
val RoseVioletLight = Color(0xFFDDD6FE)
val RoseVioletContainer = Color(0xFF5B21B6)

val CoralUrgent = Color(0xFFEF4444)
val CoralUrgentContainer = Color(0xFF7F1D1D)

val CyanMeeting = Color(0xFF06B6D4)
val CyanMeetingContainer = Color(0xFF0E7490)

// Category color helper
enum class EventColor(val hex: Long, val displayName: String, val composeColor: Color, val containerColor: Color) {
    INDIGO(0xFF6366F1, "Work", ElectricIndigo, ElectricIndigoContainer),
    TEAL(0xFF10B981, "Personal", EmeraldTeal, EmeraldTealContainer),
    AMBER(0xFFF59E0B, "Health & Habits", AmberFlare, AmberFlareContainer),
    VIOLET(0xFF8B5CF6, "Deep Work", RoseViolet, RoseVioletContainer),
    CYAN(0xFF06B6D4, "Meetings", CyanMeeting, CyanMeetingContainer),
    CORAL(0xFFEF4444, "Urgent", CoralUrgent, CoralUrgentContainer);

    companion object {
        fun fromName(name: String?): EventColor {
            return entries.find { it.name.equals(name, ignoreCase = true) } ?: INDIGO
        }
    }
}

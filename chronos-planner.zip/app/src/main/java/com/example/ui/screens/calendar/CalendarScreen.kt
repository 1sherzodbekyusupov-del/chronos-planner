package com.example.ui.screens.calendar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.EventEntity
import com.example.ui.common.CategoryPill
import com.example.ui.common.ExecutiveCard
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.viewmodel.CalendarViewMode
import com.example.ui.viewmodel.PlannerViewModel
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

@Composable
fun CalendarScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val viewMode by viewModel.calendarViewMode.collectAsState()
    val events by viewModel.events.collectAsState()
    val preferences by viewModel.userPreferences.collectAsState()

    val currentYearMonth = YearMonth.of(selectedDate.year, selectedDate.month)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // View Mode Switcher Tabs (Day, Week, Month, Year, Agenda)
        ScrollableTabRow(
            selectedTabIndex = viewMode.ordinal,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.onSurface,
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[viewMode.ordinal]),
                    color = ElectricIndigo
                )
            }
        ) {
            CalendarViewMode.entries.forEach { mode ->
                Tab(
                    selected = viewMode == mode,
                    onClick = { viewModel.setCalendarViewMode(mode) },
                    text = {
                        Text(
                            text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (viewMode == mode) FontWeight.Bold else FontWeight.Normal,
                            color = if (viewMode == mode) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    modifier = Modifier.testTag("tab_calendar_${mode.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Navigation Bar: Prev / Next / Today
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        val newDate = when (viewMode) {
                            CalendarViewMode.DAY -> selectedDate.minusDays(1)
                            CalendarViewMode.WEEK -> selectedDate.minusWeeks(1)
                            CalendarViewMode.MONTH -> selectedDate.minusMonths(1)
                            CalendarViewMode.YEAR -> selectedDate.minusYears(1)
                            CalendarViewMode.AGENDA -> selectedDate.minusWeeks(1)
                        }
                        viewModel.selectDate(newDate)
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous")
                }

                Text(
                    text = when (viewMode) {
                        CalendarViewMode.DAY -> selectedDate.format(DateTimeFormatter.ofPattern("EEE, MMM d, yyyy"))
                        CalendarViewMode.WEEK -> {
                            val start = selectedDate.with(DayOfWeek.MONDAY)
                            val end = start.plusDays(6)
                            "${start.format(DateTimeFormatter.ofPattern("MMM d"))} - ${end.format(DateTimeFormatter.ofPattern("MMM d, yyyy"))}"
                        }
                        CalendarViewMode.MONTH -> selectedDate.format(DateTimeFormatter.ofPattern("MMMM yyyy"))
                        CalendarViewMode.YEAR -> selectedDate.year.toString()
                        CalendarViewMode.AGENDA -> "Agenda • ${selectedDate.format(DateTimeFormatter.ofPattern("MMMM yyyy"))}"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = {
                        val newDate = when (viewMode) {
                            CalendarViewMode.DAY -> selectedDate.plusDays(1)
                            CalendarViewMode.WEEK -> selectedDate.plusWeeks(1)
                            CalendarViewMode.MONTH -> selectedDate.plusMonths(1)
                            CalendarViewMode.YEAR -> selectedDate.plusYears(1)
                            CalendarViewMode.AGENDA -> selectedDate.plusWeeks(1)
                        }
                        viewModel.selectDate(newDate)
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next")
                }
            }

            TextButton(
                onClick = { viewModel.selectDate(LocalDate.now()) },
                modifier = Modifier.testTag("btn_calendar_today")
            ) {
                Text("Today", color = ElectricIndigo, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content by View Mode
        when (viewMode) {
            CalendarViewMode.MONTH -> MonthView(
                currentYearMonth = currentYearMonth,
                selectedDate = selectedDate,
                events = events,
                onDateSelected = { viewModel.selectDate(it) },
                onAddEvent = { viewModel.openNewEventDialog(it) },
                onEditEvent = { viewModel.openEditEventDialog(it) },
                onDuplicateEvent = { viewModel.duplicateEvent(it) },
                onDeleteEvent = { viewModel.deleteEvent(it) },
                is24Hour = preferences.is24HourFormat
            )
            CalendarViewMode.DAY -> DayView(
                date = selectedDate,
                events = events.filter { it.startDate == selectedDate.toString() || (!it.isAllDay && it.startDate <= selectedDate.toString() && it.endDate >= selectedDate.toString()) },
                onAddEvent = { viewModel.openNewEventDialog(selectedDate, it) },
                onEditEvent = { viewModel.openEditEventDialog(it) },
                is24Hour = preferences.is24HourFormat
            )
            CalendarViewMode.WEEK -> WeekView(
                selectedDate = selectedDate,
                events = events,
                onDateSelected = { viewModel.selectDate(it) },
                onEditEvent = { viewModel.openEditEventDialog(it) },
                is24Hour = preferences.is24HourFormat
            )
            CalendarViewMode.YEAR -> YearView(
                selectedYear = selectedDate.year,
                selectedDate = selectedDate,
                events = events,
                onDateSelected = {
                    viewModel.selectDate(it)
                    viewModel.setCalendarViewMode(CalendarViewMode.DAY)
                }
            )
            CalendarViewMode.AGENDA -> AgendaView(
                selectedDate = selectedDate,
                events = events,
                onEditEvent = { viewModel.openEditEventDialog(it) },
                onDuplicateEvent = { viewModel.duplicateEvent(it) },
                onDeleteEvent = { viewModel.deleteEvent(it) },
                is24Hour = preferences.is24HourFormat
            )
        }
    }
}

@Composable
fun MonthView(
    currentYearMonth: YearMonth,
    selectedDate: LocalDate,
    events: List<EventEntity>,
    onDateSelected: (LocalDate) -> Unit,
    onAddEvent: (LocalDate) -> Unit,
    onEditEvent: (EventEntity) -> Unit,
    onDuplicateEvent: (EventEntity) -> Unit,
    onDeleteEvent: (EventEntity) -> Unit,
    is24Hour: Boolean
) {
    val eventsByDate = remember(events) { events.groupBy { it.startDate } }
    val daysInMonth = currentYearMonth.lengthOfMonth()
    val firstDayOfMonth = currentYearMonth.atDay(1)
    val firstDayOfWeek = firstDayOfMonth.dayOfWeek.value // 1 = Monday, 7 = Sunday
    val leadEmptySlots = firstDayOfWeek - 1

    val selectedDayEvents = events.filter { it.startDate == selectedDate.toString() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Days of week header (Mon, Tue, Wed, Thu, Fri, Sat, Sun)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                    Text(
                        text = day,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Calendar Grid
        item {
            val totalCells = leadEmptySlots + daysInMonth
            val rows = (totalCells + 6) / 7

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        for (c in 0 until 7) {
                            val cellIndex = r * 7 + c
                            val dayNumber = cellIndex - leadEmptySlots + 1

                            if (dayNumber in 1..daysInMonth) {
                                val date = currentYearMonth.atDay(dayNumber)
                                val isSelected = date == selectedDate
                                val isToday = date == LocalDate.now()
                                val dayEvents = eventsByDate[date.toString()] ?: emptyList()

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when {
                                                isSelected -> ElectricIndigo
                                                isToday -> ElectricIndigo.copy(alpha = 0.2f)
                                                else -> MaterialTheme.colorScheme.surface
                                            }
                                        )
                                        .clickable { onDateSelected(date) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(
                                            text = dayNumber.toString(),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                            color = when {
                                                isSelected -> Color.White
                                                isToday -> ElectricIndigo
                                                else -> MaterialTheme.colorScheme.onSurface
                                            }
                                        )

                                        // Event Indicator Dots
                                        if (dayEvents.isNotEmpty()) {
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                                modifier = Modifier.padding(top = 2.dp)
                                            ) {
                                                dayEvents.take(3).forEach { ev ->
                                                    Box(
                                                        modifier = Modifier
                                                            .size(4.dp)
                                                            .clip(CircleShape)
                                                            .background(if (isSelected) Color.White else Color(ev.colorHex))
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Selected Date Header and List of Events
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMM d"))} (${selectedDayEvents.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = { onAddEvent(selectedDate) }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Event", tint = ElectricIndigo)
                }
            }
        }

        if (selectedDayEvents.isEmpty()) {
            item {
                ExecutiveCard {
                    Text(
                        text = "No events scheduled for this day.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(selectedDayEvents) { event ->
                CalendarEventItemCard(
                    event = event,
                    onEdit = { onEditEvent(event) },
                    onDuplicate = { onDuplicateEvent(event) },
                    onDelete = { onDeleteEvent(event) },
                    is24Hour = is24Hour
                )
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun DayView(
    date: LocalDate,
    events: List<EventEntity>,
    onAddEvent: (startMinutes: Int) -> Unit,
    onEditEvent: (EventEntity) -> Unit,
    is24Hour: Boolean
) {
    val hours = (6..23).toList()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                text = "Day Schedule: ${date.format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(hours) { hour ->
            val slotStartMin = hour * 60
            val slotEndMin = (hour + 1) * 60
            val slotEvents = events.filter { ev ->
                !ev.isAllDay && ev.startMinutes < slotEndMin && ev.endMinutes > slotStartMin
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clickable { onAddEvent(slotStartMin) },
                verticalAlignment = Alignment.Top
            ) {
                // Time Label
                Text(
                    text = if (is24Hour) String.format("%02d:00", hour) else {
                        val h = if (hour % 12 == 0) 12 else hour % 12
                        val p = if (hour >= 12) "PM" else "AM"
                        "$h $p"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(54.dp)
                )

                // Timeline Track
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(60.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (slotEvents.isNotEmpty()) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    if (slotEvents.isEmpty()) {
                        Text(
                            text = "Free",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            modifier = Modifier.align(Alignment.CenterStart)
                        )
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            slotEvents.forEach { ev ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(ev.colorHex),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onEditEvent(ev) }
                                ) {
                                    Column(modifier = Modifier.padding(6.dp)) {
                                        Text(
                                            text = ev.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "${ev.startMinutes / 60}:${String.format("%02d", ev.startMinutes % 60)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun WeekView(
    selectedDate: LocalDate,
    events: List<EventEntity>,
    onDateSelected: (LocalDate) -> Unit,
    onEditEvent: (EventEntity) -> Unit,
    is24Hour: Boolean
) {
    val startOfWeek = selectedDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val weekDays = (0..6).map { startOfWeek.plusDays(it.toLong()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                weekDays.forEach { date ->
                    val isSelected = date == selectedDate
                    val isToday = date == LocalDate.now()

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) ElectricIndigo else MaterialTheme.colorScheme.surface)
                            .clickable { onDateSelected(date) }
                            .padding(vertical = 8.dp, horizontal = 10.dp)
                    ) {
                        Text(
                            text = date.format(DateTimeFormatter.ofPattern("EEE")),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = date.dayOfMonth.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else if (isToday) ElectricIndigo else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        items(weekDays) { date ->
            val dayEvents = events.filter { it.startDate == date.toString() }

            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = date.format(DateTimeFormatter.ofPattern("EEEE, MMM d")),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (date == selectedDate) ElectricIndigo else MaterialTheme.colorScheme.onSurface
                    )

                    if (dayEvents.isEmpty()) {
                        Text(
                            text = "No events",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        dayEvents.forEach { ev ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onEditEvent(ev) }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(ev.colorHex))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = ev.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = if (ev.isAllDay) "All Day" else "${ev.startMinutes / 60}:${String.format("%02d", ev.startMinutes % 60)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun YearView(
    selectedYear: Int,
    selectedDate: LocalDate,
    events: List<EventEntity>,
    onDateSelected: (LocalDate) -> Unit
) {
    val months = (1..12).map { YearMonth.of(selectedYear, it) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(months) { ym ->
            ExecutiveCard(
                onClick = { onDateSelected(ym.atDay(1)) }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = ym.month.name.take(3),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = ElectricIndigo
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${ym.lengthOfMonth()} days",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AgendaView(
    selectedDate: LocalDate,
    events: List<EventEntity>,
    onEditEvent: (EventEntity) -> Unit,
    onDuplicateEvent: (EventEntity) -> Unit,
    onDeleteEvent: (EventEntity) -> Unit,
    is24Hour: Boolean
) {
    val sorted = events.sortedBy { it.startDate }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Chronological Agenda (${sorted.size})",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (sorted.isEmpty()) {
            item {
                ExecutiveCard {
                    Text("No upcoming events in the calendar.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(sorted) { event ->
                CalendarEventItemCard(
                    event = event,
                    onEdit = { onEditEvent(event) },
                    onDuplicate = { onDuplicateEvent(event) },
                    onDelete = { onDeleteEvent(event) },
                    is24Hour = is24Hour
                )
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }
}

@Composable
fun CalendarEventItemCard(
    event: EventEntity,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    is24Hour: Boolean
) {
    val accent = Color(event.colorHex)

    ExecutiveCard(
        onClick = onEdit,
        borderColor = accent.copy(alpha = 0.35f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(42.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accent)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "${event.startDate} • ${if (event.isAllDay) "All Day" else "${event.startMinutes / 60}:${String.format("%02d", event.startMinutes % 60)}"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    CategoryPill(category = event.category)
                }
            }

            IconButton(onClick = onDuplicate) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

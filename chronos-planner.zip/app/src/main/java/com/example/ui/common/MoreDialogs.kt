package com.example.ui.common

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.entity.GoalEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.NoteEntity
import com.example.data.entity.RoutineTemplateEntity
import com.example.data.entity.TaskEntity
import com.example.ui.theme.CoralUrgent
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class SubtaskItem(val id: Int, val title: String, val isCompleted: Boolean)
data class MilestoneItem(val title: String, val isDone: Boolean)

@Composable
fun TaskEditDialog(
    task: TaskEntity,
    onDismiss: () -> Unit,
    onSave: (TaskEntity) -> Unit,
    onDelete: ((TaskEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(task.title) }
    var description by remember { mutableStateOf(task.description) }
    var dueDate by remember { mutableStateOf(task.dueDate ?: LocalDate.now().toString()) }
    var priority by remember { mutableStateOf(task.priority) }
    var category by remember { mutableStateOf(task.category) }
    var estimatedMinutes by remember { mutableIntStateOf(task.estimatedMinutes) }

    val subtasks = remember {
        val list = mutableStateListOf<SubtaskItem>()
        try {
            val json = JSONArray(task.subtasksJson)
            for (i in 0 until json.length()) {
                val obj = json.getJSONObject(i)
                list.add(
                    SubtaskItem(
                        id = obj.optInt("id", i),
                        title = obj.optString("title", ""),
                        isCompleted = obj.optBoolean("isCompleted", false)
                    )
                )
            }
        } catch (_: Exception) {}
        list
    }
    var newSubtaskText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (task.id == 0L) "New Task" else "Edit Task",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_task_title")
                )

                // Priority Selector
                Text("Priority", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("LOW", "MEDIUM", "HIGH", "URGENT").forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (priority == p) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { priority = p }
                        ) {
                            Text(
                                text = p.lowercase().replaceFirstChar { it.uppercase() },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (priority == p) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Category Selector
                Text("Category", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Work", "Personal", "Deep Work", "Health").forEach { cat ->
                        CategoryPill(
                            category = cat,
                            isSelected = category == cat,
                            onClick = { category = cat }
                        )
                    }
                }

                // Subtasks checklist builder
                Text("Subtasks & Checklist", style = MaterialTheme.typography.labelSmall)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    subtasks.forEachIndexed { index, sub ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = sub.isCompleted,
                                onCheckedChange = { checked ->
                                    subtasks[index] = sub.copy(isCompleted = checked)
                                }
                            )
                            Text(
                                text = sub.title,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { subtasks.removeAt(index) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete subtask", tint = CoralUrgent)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newSubtaskText,
                            onValueChange = { newSubtaskText = it },
                            placeholder = { Text("Add subtask item...") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (newSubtaskText.isNotBlank()) {
                                    subtasks.add(SubtaskItem(subtasks.size + 1, newSubtaskText.trim(), false))
                                    newSubtaskText = ""
                                }
                            }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add")
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (task.id != 0L && onDelete != null) {
                        TextButton(
                            onClick = { onDelete(task) },
                            colors = ButtonDefaults.textButtonColors(contentColor = CoralUrgent)
                        ) {
                            Text("Delete")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            val jsonArray = JSONArray()
                            subtasks.forEach {
                                val obj = JSONObject()
                                obj.put("id", it.id)
                                obj.put("title", it.title)
                                obj.put("isCompleted", it.isCompleted)
                                jsonArray.put(obj)
                            }

                            val updated = task.copy(
                                title = title.trim(),
                                description = description.trim(),
                                dueDate = dueDate,
                                priority = priority,
                                category = category,
                                estimatedMinutes = estimatedMinutes,
                                subtasksJson = jsonArray.toString()
                            )
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldTeal),
                        modifier = Modifier.testTag("btn_save_task")
                    ) {
                        Text("Save Task")
                    }
                }
            }
        }
    }
}

@Composable
fun HabitEditDialog(
    habit: HabitEntity,
    onDismiss: () -> Unit,
    onSave: (HabitEntity) -> Unit,
    onDelete: ((HabitEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(habit.title) }
    var description by remember { mutableStateOf(habit.description) }
    var category by remember { mutableStateOf(habit.category) }
    var frequency by remember { mutableStateOf(habit.frequency) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (habit.id == 0L) "Create Habit" else "Edit Habit",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Habit Title") },
                    placeholder = { Text("e.g. Read 30 mins, Exercise, 2L Water") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_habit_title")
                )

                Text("Frequency", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("DAILY", "WEEKDAYS", "WEEKENDS", "3X_WEEK").forEach { freq ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (frequency == freq) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { frequency = freq }
                        ) {
                            Text(
                                text = freq.replace("_", " "),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (frequency == freq) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (habit.id != 0L && onDelete != null) {
                        TextButton(
                            onClick = { onDelete(habit) },
                            colors = ButtonDefaults.textButtonColors(contentColor = CoralUrgent)
                        ) {
                            Text("Delete")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            onSave(habit.copy(title = title.trim(), description = description.trim(), category = category, frequency = frequency))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        modifier = Modifier.testTag("btn_save_habit")
                    ) {
                        Text("Save Habit")
                    }
                }
            }
        }
    }
}

@Composable
fun ApplyRoutineDialog(
    routine: RoutineTemplateEntity,
    selectedDate: LocalDate,
    onDismiss: () -> Unit,
    onApply: (date: LocalDate, startMinutes: Int, conflictStrategy: String) -> Unit
) {
    var startHour by remember { mutableIntStateOf(8) }
    var conflictStrategy by remember { mutableStateOf("KEEP_ALL") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Apply ${routine.name}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Schedule this template to ${selectedDate}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text("Start Time", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(7, 8, 9, 13, 18).forEach { hour ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (startHour == hour) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { startHour = hour }
                        ) {
                            Text(
                                text = String.format("%02d:00", hour),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (startHour == hour) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Text("Conflict Handling", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (conflictStrategy == "KEEP_ALL") ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.clickable { conflictStrategy = "KEEP_ALL" }
                    ) {
                        Text(
                            text = "Keep Existing Events",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (conflictStrategy == "KEEP_ALL") Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (conflictStrategy == "REPLACE_CONFLICTS") CoralUrgent else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.clickable { conflictStrategy = "REPLACE_CONFLICTS" }
                    ) {
                        Text(
                            text = "Replace Conflicting",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (conflictStrategy == "REPLACE_CONFLICTS") Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onApply(selectedDate, startHour * 60, conflictStrategy) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        modifier = Modifier.testTag("btn_confirm_apply_routine")
                    ) {
                        Text("Apply to Schedule")
                    }
                }
            }
        }
    }
}

@Composable
fun GoalEditDialog(
    goal: GoalEntity,
    onDismiss: () -> Unit,
    onSave: (GoalEntity) -> Unit,
    onDelete: ((GoalEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(goal.title) }
    var description by remember { mutableStateOf(goal.description) }
    var type by remember { mutableStateOf(goal.type) }
    var targetDate by remember { mutableStateOf(goal.targetDate) }
    var progress by remember { mutableIntStateOf(goal.progressPercent) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (goal.id == 0L) "New Goal" else "Edit Goal",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Goal Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Horizon", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("DAILY", "WEEKLY", "MONTHLY", "LONG_TERM").forEach { t ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (type == t) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { type = t }
                        ) {
                            Text(
                                text = t.replace("_", " "),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (type == t) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Text("Progress: $progress%", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 25, 50, 75, 100).forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (progress == p) EmeraldTeal else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { progress = p }
                        ) {
                            Text(
                                text = "$p%",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (progress == p) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (goal.id != 0L && onDelete != null) {
                        TextButton(
                            onClick = { onDelete(goal) },
                            colors = ButtonDefaults.textButtonColors(contentColor = CoralUrgent)
                        ) {
                            Text("Delete")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            onSave(goal.copy(title = title.trim(), description = description.trim(), type = type, targetDate = targetDate, progressPercent = progress, isCompleted = progress == 100))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
                    ) {
                        Text("Save Goal")
                    }
                }
            }
        }
    }
}

@Composable
fun NoteEditDialog(
    note: NoteEntity,
    onDismiss: () -> Unit,
    onSave: (NoteEntity) -> Unit,
    onDelete: ((NoteEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(note.title) }
    var content by remember { mutableStateOf(note.content) }
    var tags by remember { mutableStateOf(note.tags) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = if (note.id == 0L) "Quick Capture Note" else "Edit Note",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content / Idea") },
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Tags (comma-separated)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (note.id != 0L && onDelete != null) {
                        TextButton(
                            onClick = { onDelete(note) },
                            colors = ButtonDefaults.textButtonColors(contentColor = CoralUrgent)
                        ) {
                            Text("Delete")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isBlank() && content.isBlank()) return@Button
                            onSave(note.copy(title = title.trim(), content = content.trim(), tags = tags.trim()))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
                    ) {
                        Text("Save Note")
                    }
                }
            }
        }
    }
}

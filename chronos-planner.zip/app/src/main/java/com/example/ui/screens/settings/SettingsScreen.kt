package com.example.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.common.ExecutiveCard
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.viewmodel.PlannerViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: PlannerViewModel,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.userPreferences.collectAsState()
    val scope = rememberCoroutineScope()
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Preferences & System",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Personalize scheduling engine, notifications, and export",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Language & Localization Section
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = ElectricIndigo)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Language / Til", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        val isEn = preferences.language == "en"
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isEn) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable {
                                scope.launch { viewModel.preferencesRepository.updateLanguage("en") }
                            }
                        ) {
                            Text(
                                text = "English",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isEn) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }

                        val isUz = preferences.language == "uz"
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isUz) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable {
                                scope.launch { viewModel.preferencesRepository.updateLanguage("uz") }
                            }
                        ) {
                            Text(
                                text = "O'zbekcha",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isUz) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Time & Calendar Format
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = ElectricIndigo)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Time & Calendar Format", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("24-Hour Time Format", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = if (preferences.is24HourFormat) "e.g. 14:30" else "e.g. 2:30 PM",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = preferences.is24HourFormat,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateTimeFormat(it) } },
                            modifier = Modifier.testTag("switch_24_hour")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Start Week on Monday", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = if (preferences.firstDayIsMonday) "Monday - Sunday" else "Sunday - Saturday",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = preferences.firstDayIsMonday,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateFirstDayIsMonday(it) } },
                            modifier = Modifier.testTag("switch_first_day")
                        )
                    }
                }
            }
        }

        // Theme Mode
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Brightness4, contentDescription = null, tint = ElectricIndigo)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Appearance Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Executive Dark Theme", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = preferences.isDarkTheme,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateDarkTheme(it) } },
                            modifier = Modifier.testTag("switch_dark_theme")
                        )
                    }
                }
            }
        }

        // Notifications Preferences
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = ElectricIndigo)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Notifications & Alarms", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Advance Event Reminders", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = preferences.notificationsEnabled,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateNotificationsEnabled(it) } }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Reminder Sound", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = preferences.notificationSound,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateNotificationSound(it) } }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Vibration", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = preferences.notificationVibrate,
                            onCheckedChange = { scope.launch { viewModel.preferencesRepository.updateNotificationVibrate(it) } }
                        )
                    }
                }
            }
        }

        // Data Storage & Backup
        item {
            ExecutiveCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = EmeraldTeal)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Data Export & Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "All schedules, tasks, habits, and notes are securely persisted on-device in Room Database with zero external data leaks.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            scope.launch {
                                exportedJsonText = viewModel.repository.exportDataJson()
                                showExportDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldTeal),
                        modifier = Modifier.testTag("btn_export_json")
                    ) {
                        Text("Export Backup JSON", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(70.dp)) }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Data Export JSON") },
            text = {
                Text(
                    text = exportedJsonText.take(600) + if (exportedJsonText.length > 600) "\n\n... (full JSON exported successfully)" else "",
                    style = MaterialTheme.typography.bodySmall
                )
            },
            confirmButton = {
                Button(onClick = {
                    showExportDialog = false
                    viewModel.showSnack("Backup exported successfully")
                }) {
                    Text("Done")
                }
            }
        )
    }
}

package com.example.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.entity.EventEntity
import com.example.data.entity.GoalEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.NoteEntity
import com.example.data.entity.RoutineTemplateEntity
import com.example.data.entity.TaskEntity
import com.example.ui.theme.AmberFlare
import com.example.ui.theme.CoralUrgent
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.theme.EventColor
import com.example.ui.theme.RoseViolet
import java.time.LocalDate

@Composable
fun ExecutiveCard(
    modifier: Modifier = Modifier,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Box(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
fun CategoryPill(
    category: String,
    isSelected: Boolean = true,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val eventColor = when (category.lowercase()) {
        "work" -> EventColor.INDIGO
        "personal" -> EventColor.TEAL
        "health", "health & habits" -> EventColor.AMBER
        "deep work" -> EventColor.VIOLET
        "meetings" -> EventColor.CYAN
        "urgent" -> EventColor.CORAL
        else -> EventColor.INDIGO
    }

    val bg = if (isSelected) eventColor.composeColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
    val borderCol = if (isSelected) eventColor.composeColor else MaterialTheme.colorScheme.outlineVariant

    Surface(
        modifier = modifier
            .clip(CircleShape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = CircleShape,
        color = bg,
        border = BorderStroke(1.dp, borderCol)
    ) {
        Text(
            text = category,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = if (isSelected) eventColor.composeColor else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PriorityBadge(priority: String) {
    val (color, label) = when (priority.uppercase()) {
        "URGENT" -> CoralUrgent to "Urgent"
        "HIGH" -> AmberFlare to "High"
        "MEDIUM" -> ElectricIndigo to "Medium"
        else -> EmeraldTeal to "Low"
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
fun ConflictWarningBanner(
    conflicts: List<EventEntity>,
    onIgnore: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Conflict Warning",
                tint = CoralUrgent,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Schedule Conflict Detected",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                Text(
                    text = "This time overlaps with ${conflicts.size} existing scheduled event(s):",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                conflicts.forEach { event ->
                    Text(
                        text = "• ${event.title} (${formatTimeRange(event.startMinutes, event.endMinutes)})",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onIgnore,
                colors = ButtonDefaults.buttonColors(containerColor = CoralUrgent),
                modifier = Modifier.testTag("btn_schedule_anyway")
            ) {
                Text("Schedule Anyway")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_conflict_cancel")
            ) {
                Text("Adjust Time")
            }
        }
    )
}

fun formatTimeRange(startMin: Int, endMin: Int): String {
    val sh = startMin / 60
    val sm = startMin % 60
    val eh = endMin / 60
    val em = endMin % 60
    return String.format("%02d:%02d - %02d:%02d", sh, sm, eh, em)
}

@Composable
fun ExecutiveFabMenu(
    onNewEvent: () -> Unit,
    onNewTask: () -> Unit,
    onNewHabit: () -> Unit,
    onNewNote: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                FabSubItem(label = "New Event", icon = Icons.Default.Event, color = ElectricIndigo) {
                    expanded = false
                    onNewEvent()
                }
                FabSubItem(label = "New Task", icon = Icons.Default.Check, color = EmeraldTeal) {
                    expanded = false
                    onNewTask()
                }
                FabSubItem(label = "New Habit", icon = Icons.Default.Repeat, color = AmberFlare) {
                    expanded = false
                    onNewHabit()
                }
                FabSubItem(label = "Quick Note", icon = Icons.Default.NoteAlt, color = RoseViolet) {
                    expanded = false
                    onNewNote()
                }
            }
        }

        FloatingActionButton(
            onClick = { expanded = !expanded },
            shape = CircleShape,
            containerColor = ElectricIndigo,
            contentColor = Color.White,
            modifier = Modifier
                .size(56.dp)
                .testTag("fab_quick_capture")
        ) {
            Icon(
                imageVector = if (expanded) Icons.Default.Close else Icons.Default.Add,
                contentDescription = "Quick capture",
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun FabSubItem(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun EventEditDialog(
    event: EventEntity,
    onDismiss: () -> Unit,
    onSave: (EventEntity) -> Unit,
    onDelete: ((EventEntity) -> Unit)? = null
) {
    var title by remember { mutableStateOf(event.title) }
    var description by remember { mutableStateOf(event.description) }
    var location by remember { mutableStateOf(event.location) }
    var startDate by remember { mutableStateOf(event.startDate) }
    var startHours by remember { mutableIntStateOf(event.startMinutes / 60) }
    var startMins by remember { mutableIntStateOf(event.startMinutes % 60) }
    var durationMins by remember { mutableIntStateOf(maxOf(15, event.endMinutes - event.startMinutes)) }
    var isAllDay by remember { mutableStateOf(event.isAllDay) }
    var category by remember { mutableStateOf(event.category) }
    var recurrence by remember { mutableStateOf(event.recurrenceRule) }
    var reminderMins by remember { mutableIntStateOf(event.reminderMinutesBefore) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (event.id == 0L) "New Calendar Event" else "Edit Event",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Event Title") },
                    placeholder = { Text("e.g. Quarterly Strategic Review") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_event_title")
                )

                // Category Chips
                Text("Category", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf("Work", "Personal", "Deep Work", "Health", "Meetings").forEach { cat ->
                        CategoryPill(
                            category = cat,
                            isSelected = category == cat,
                            onClick = { category = cat }
                        )
                    }
                }

                // Time and Duration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("All-Day Event", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = isAllDay,
                        onCheckedChange = { isAllDay = it },
                        modifier = Modifier.testTag("switch_all_day")
                    )
                }

                if (!isAllDay) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = String.format("%02d:%02d", startHours, startMins),
                            onValueChange = {
                                val parts = it.split(":")
                                if (parts.size == 2) {
                                    parts[0].toIntOrNull()?.let { h -> if (h in 0..23) startHours = h }
                                    parts[1].toIntOrNull()?.let { m -> if (m in 0..59) startMins = m }
                                }
                            },
                            label = { Text("Start Time (HH:MM)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = durationMins.toString(),
                            onValueChange = { durationMins = it.toIntOrNull() ?: 30 },
                            label = { Text("Duration (mins)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Recurrence & Reminder
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Repeat", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("NONE", "DAILY", "WEEKLY").forEach { rule ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (recurrence == rule) ElectricIndigo else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .clickable { recurrence = rule }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Text(
                                        text = rule.lowercase().replaceFirstChar { it.uppercase() },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (recurrence == rule) Color.White else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Reminder", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(5, 15, 30, 60).forEach { mins ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (reminderMins == mins) AmberFlare else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .clickable { reminderMins = mins }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${mins}m",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (reminderMins == mins) Color.Black else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location / Video Link") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Notes / Agenda") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (event.id != 0L && onDelete != null) {
                        TextButton(
                            onClick = { onDelete(event) },
                            colors = ButtonDefaults.textButtonColors(contentColor = CoralUrgent)
                        ) {
                            Text("Delete")
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            val startTotal = if (isAllDay) -1 else (startHours * 60 + startMins)
                            val endTotal = if (isAllDay) -1 else (startTotal + durationMins)
                            val col = EventColor.fromName(category).hex

                            val updated = event.copy(
                                title = title.trim(),
                                description = description.trim(),
                                location = location.trim(),
                                startDate = startDate,
                                endDate = startDate,
                                startMinutes = startTotal,
                                endMinutes = endTotal,
                                isAllDay = isAllDay,
                                category = category,
                                colorHex = col,
                                recurrenceRule = recurrence,
                                reminderMinutesBefore = reminderMins
                            )
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        modifier = Modifier.testTag("btn_save_event")
                    ) {
                        Text("Save Event")
                    }
                }
            }
        }
    }
}

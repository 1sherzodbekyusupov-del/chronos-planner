package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NoteAlt
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewTimeline
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.common.ApplyRoutineDialog
import com.example.ui.common.ConflictWarningBanner
import com.example.ui.common.EventEditDialog
import com.example.ui.common.ExecutiveFabMenu
import com.example.ui.common.GoalEditDialog
import com.example.ui.common.HabitEditDialog
import com.example.ui.common.NoteEditDialog
import com.example.ui.common.TaskEditDialog
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.goals.GoalsScreen
import com.example.ui.screens.habits.HabitsScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.notes.NotesScreen
import com.example.ui.screens.planner.DailyPlannerScreen
import com.example.ui.screens.routines.RoutinesScreen
import com.example.ui.screens.search.GlobalSearchScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.tasks.TasksScreen
import com.example.ui.theme.ChronosTheme
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.EmeraldTeal
import com.example.ui.viewmodel.PlannerViewModel
import com.example.ui.viewmodel.ScreenTab
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val viewModel: PlannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChronosApp(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChronosApp(viewModel: PlannerViewModel) {
    val context = LocalContext.current
    val preferences by viewModel.userPreferences.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()

    // Notification Permission launcher for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionCheck = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    var isSearching by remember { mutableStateOf(false) }

    // Dialog & Conflict States
    val showEventDialog by viewModel.showEventDialog.collectAsState()
    val eventToEdit by viewModel.eventToEdit.collectAsState()
    val conflictWarning by viewModel.conflictWarning.collectAsState()

    val showTaskDialog by viewModel.showTaskDialog.collectAsState()
    val taskToEdit by viewModel.taskToEdit.collectAsState()

    val showHabitDialog by viewModel.showHabitDialog.collectAsState()
    val habitToEdit by viewModel.habitToEdit.collectAsState()

    val showApplyRoutineDialog by viewModel.showApplyRoutineDialog.collectAsState()

    val showGoalDialog by viewModel.showGoalDialog.collectAsState()
    val goalToEdit by viewModel.goalToEdit.collectAsState()

    val showNoteDialog by viewModel.showNoteDialog.collectAsState()
    val noteToEdit by viewModel.noteToEdit.collectAsState()

    val snackMessage by viewModel.snackMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackMessage) {
        snackMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackMessage()
        }
    }

    // Predictive back handling
    BackHandler(enabled = isSearching || currentTab != ScreenTab.HOME) {
        if (isSearching) {
            isSearching = false
        } else {
            viewModel.selectTab(ScreenTab.HOME)
        }
    }

    ChronosTheme(darkTheme = preferences.isDarkTheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Surface(
                    color = MaterialTheme.colorScheme.background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(top = 36.dp, start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Branding Title
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(ElectricIndigo),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "C",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Chronos",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Secondary Quick Destination Icons (Search, Routines, Goals, Notes, Settings)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                IconButton(
                                    onClick = { isSearching = !isSearching },
                                    modifier = Modifier.size(38.dp).testTag("btn_top_search")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search",
                                        tint = if (isSearching) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        isSearching = false
                                        viewModel.selectTab(ScreenTab.ROUTINES)
                                    },
                                    modifier = Modifier.size(38.dp).testTag("btn_top_routines")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WbSunny,
                                        contentDescription = "Routines",
                                        tint = if (currentTab == ScreenTab.ROUTINES) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        isSearching = false
                                        viewModel.selectTab(ScreenTab.GOALS)
                                    },
                                    modifier = Modifier.size(38.dp).testTag("btn_top_goals")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Flag,
                                        contentDescription = "Goals",
                                        tint = if (currentTab == ScreenTab.GOALS) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        isSearching = false
                                        viewModel.selectTab(ScreenTab.NOTES)
                                    },
                                    modifier = Modifier.size(38.dp).testTag("btn_top_notes")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NoteAlt,
                                        contentDescription = "Notes",
                                        tint = if (currentTab == ScreenTab.NOTES) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        isSearching = false
                                        viewModel.selectTab(ScreenTab.SETTINGS)
                                    },
                                    modifier = Modifier.size(38.dp).testTag("btn_top_settings")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "Settings",
                                        tint = if (currentTab == ScreenTab.SETTINGS) ElectricIndigo else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Triple(ScreenTab.HOME, "Home", Icons.Default.Home),
                        Triple(ScreenTab.CALENDAR, "Calendar", Icons.Default.CalendarMonth),
                        Triple(ScreenTab.PLANNER, "Planner", Icons.Default.ViewTimeline),
                        Triple(ScreenTab.TASKS, "Tasks", Icons.Default.Check),
                        Triple(ScreenTab.HABITS, "Habits", Icons.Default.Repeat)
                    )

                    tabs.forEach { (tab, label, icon) ->
                        val selected = currentTab == tab && !isSearching
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                isSearching = false
                                viewModel.selectTab(tab)
                            },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ElectricIndigo,
                                selectedTextColor = ElectricIndigo,
                                indicatorColor = ElectricIndigo.copy(alpha = 0.15f),
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            },
            floatingActionButton = {
                ExecutiveFabMenu(
                    onNewEvent = { viewModel.openNewEventDialog() },
                    onNewTask = { viewModel.openNewTaskDialog() },
                    onNewHabit = { viewModel.openNewHabitDialog() },
                    onNewNote = { viewModel.openNewNoteDialog() }
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (isSearching) {
                    GlobalSearchScreen(
                        viewModel = viewModel,
                        onClose = { isSearching = false }
                    )
                } else {
                    when (currentTab) {
                        ScreenTab.HOME -> HomeScreen(viewModel = viewModel)
                        ScreenTab.CALENDAR -> CalendarScreen(viewModel = viewModel)
                        ScreenTab.PLANNER -> DailyPlannerScreen(viewModel = viewModel)
                        ScreenTab.TASKS -> TasksScreen(viewModel = viewModel)
                        ScreenTab.HABITS -> HabitsScreen(viewModel = viewModel)
                        ScreenTab.ROUTINES -> RoutinesScreen(viewModel = viewModel)
                        ScreenTab.GOALS -> GoalsScreen(viewModel = viewModel)
                        ScreenTab.NOTES -> NotesScreen(viewModel = viewModel)
                        ScreenTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }

        // Event Dialog
        if (showEventDialog && eventToEdit != null) {
            EventEditDialog(
                event = eventToEdit!!,
                onDismiss = { viewModel.dismissEventDialog() },
                onSave = { updated -> viewModel.saveEvent(updated) },
                onDelete = { toDelete ->
                    viewModel.deleteEvent(toDelete)
                    viewModel.dismissEventDialog()
                }
            )
        }

        // Conflict Warning Alert
        if (conflictWarning != null && conflictWarning?.pendingEvent != null) {
            ConflictWarningBanner(
                conflicts = conflictWarning!!.conflictingEvents,
                onIgnore = {
                    viewModel.saveEvent(conflictWarning!!.pendingEvent!!, bypassConflictCheck = true)
                },
                onDismiss = {
                    viewModel.dismissEventDialog()
                }
            )
        }

        // Task Dialog
        if (showTaskDialog && taskToEdit != null) {
            TaskEditDialog(
                task = taskToEdit!!,
                onDismiss = { viewModel.dismissTaskDialog() },
                onSave = { updated -> viewModel.saveTask(updated) },
                onDelete = { toDelete ->
                    viewModel.deleteTask(toDelete)
                    viewModel.dismissTaskDialog()
                }
            )
        }

        // Habit Dialog
        if (showHabitDialog && habitToEdit != null) {
            HabitEditDialog(
                habit = habitToEdit!!,
                onDismiss = { viewModel.dismissHabitDialog() },
                onSave = { updated -> viewModel.saveHabit(updated) },
                onDelete = { toDelete ->
                    viewModel.deleteHabit(toDelete)
                    viewModel.dismissHabitDialog()
                }
            )
        }

        // Apply Routine Dialog
        if (showApplyRoutineDialog != null) {
            ApplyRoutineDialog(
                routine = showApplyRoutineDialog!!,
                selectedDate = selectedDate,
                onDismiss = { viewModel.dismissApplyRoutine() },
                onApply = { date, baseMinutes, conflictStrategy ->
                    viewModel.applyRoutine(showApplyRoutineDialog!!, date, baseMinutes, conflictStrategy)
                }
            )
        }

        // Goal Dialog
        if (showGoalDialog && goalToEdit != null) {
            GoalEditDialog(
                goal = goalToEdit!!,
                onDismiss = { viewModel.dismissGoalDialog() },
                onSave = { updated -> viewModel.saveGoal(updated) },
                onDelete = { toDelete ->
                    viewModel.deleteGoal(toDelete)
                    viewModel.dismissGoalDialog()
                }
            )
        }

        // Note Dialog
        if (showNoteDialog && noteToEdit != null) {
            NoteEditDialog(
                note = noteToEdit!!,
                onDismiss = { viewModel.dismissNoteDialog() },
                onSave = { updated -> viewModel.saveNote(updated) },
                onDelete = { toDelete ->
                    viewModel.deleteNote(toDelete)
                    viewModel.dismissNoteDialog()
                }
            )
        }
    }
}

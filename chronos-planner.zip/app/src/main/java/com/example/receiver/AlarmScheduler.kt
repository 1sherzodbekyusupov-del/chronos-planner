package com.example.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.entity.EventEntity
import com.example.data.entity.TaskEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class AlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleEventReminder(event: EventEntity) {
        if (event.isAllDay) return
        try {
            val date = LocalDate.parse(event.startDate)
            val hours = event.startMinutes / 60
            val minutes = event.startMinutes % 60
            val eventDateTime = LocalDateTime.of(date, LocalTime.of(hours, minutes))
            val reminderDateTime = eventDateTime.minusMinutes(event.reminderMinutesBefore.toLong())

            val epochMillis = reminderDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val nowMillis = System.currentTimeMillis()

            if (epochMillis <= nowMillis) {
                // If it's already past, don't schedule
                return
            }

            val intent = Intent(context, CalendarReminderReceiver::class.java).apply {
                action = CalendarReminderReceiver.ACTION_EVENT_REMINDER
                putExtra(CalendarReminderReceiver.EXTRA_ID, event.id)
                putExtra(CalendarReminderReceiver.EXTRA_TITLE, event.title)
                putExtra(CalendarReminderReceiver.EXTRA_MESSAGE, "Starting in ${event.reminderMinutesBefore}m at ${event.location.ifEmpty { "Scheduled time" }}")
                putExtra(CalendarReminderReceiver.EXTRA_TYPE, "EVENT")
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                event.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to schedule event reminder", e)
        }
    }

    fun scheduleTaskReminder(task: TaskEntity) {
        if (task.dueDate == null || task.dueMinutes == null || task.isCompleted) return
        try {
            val date = LocalDate.parse(task.dueDate)
            val hours = task.dueMinutes / 60
            val minutes = task.dueMinutes % 60
            val dueDateTime = LocalDateTime.of(date, LocalTime.of(hours, minutes))
            val reminderDateTime = dueDateTime.minusMinutes(task.reminderMinutesBefore.toLong())

            val epochMillis = reminderDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            if (epochMillis <= System.currentTimeMillis()) return

            val intent = Intent(context, CalendarReminderReceiver::class.java).apply {
                action = CalendarReminderReceiver.ACTION_EVENT_REMINDER
                putExtra(CalendarReminderReceiver.EXTRA_ID, (task.id + 100000))
                putExtra(CalendarReminderReceiver.EXTRA_TITLE, "Task Due: ${task.title}")
                putExtra(CalendarReminderReceiver.EXTRA_MESSAGE, "Priority: ${task.priority} • Due soon")
                putExtra(CalendarReminderReceiver.EXTRA_TYPE, "TASK")
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                (task.id + 100000).toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to schedule task reminder", e)
        }
    }

    fun cancelReminder(id: Long) {
        try {
            val intent = Intent(context, CalendarReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                id.toInt(),
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
            }
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to cancel reminder", e)
        }
    }
}

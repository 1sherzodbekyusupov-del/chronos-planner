package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.PlannerDao
import com.example.data.entity.EventEntity
import com.example.data.entity.GoalEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.HabitLogEntity
import com.example.data.entity.NoteEntity
import com.example.data.entity.RoutineTemplateEntity
import com.example.data.entity.TaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        EventEntity::class,
        TaskEntity::class,
        HabitEntity::class,
        HabitLogEntity::class,
        RoutineTemplateEntity::class,
        GoalEntity::class,
        NoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun plannerDao(): PlannerDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "chronos_planner.db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // Pre-populate initial starter data (defaults)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database.plannerDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: PlannerDao) {
            val today = LocalDate.now().toString()
            val tomorrow = LocalDate.now().plusDays(1).toString()
            val inTwoDays = LocalDate.now().plusDays(2).toString()

            // Initial Events
            dao.insertEvent(
                EventEntity(
                    title = "Executive Product Strategy",
                    description = "Q4 roadmap alignment and architecture review",
                    location = "Executive Boardroom / Zoom",
                    startDate = today,
                    endDate = today,
                    startMinutes = 570, // 09:30 AM
                    endMinutes = 630,   // 10:30 AM
                    category = "Work",
                    colorHex = 0xFF6366F1,
                    reminderMinutesBefore = 15
                )
            )
            dao.insertEvent(
                EventEntity(
                    title = "Deep Focus: Design System Sprint",
                    description = "Implement custom glassmorphism components and typography tokens",
                    location = "Deep Work Lab",
                    startDate = today,
                    endDate = today,
                    startMinutes = 660, // 11:00 AM
                    endMinutes = 780,   // 01:00 PM
                    category = "Deep Work",
                    colorHex = 0xFF8B5CF6,
                    reminderMinutesBefore = 10
                )
            )
            dao.insertEvent(
                EventEntity(
                    title = "Weekly 1-on-1 Sync",
                    description = "Career development & project velocity feedback",
                    location = "Meeting Room B",
                    startDate = today,
                    endDate = today,
                    startMinutes = 900, // 03:00 PM
                    endMinutes = 930,   // 03:30 PM
                    category = "Meetings",
                    colorHex = 0xFF06B6D4,
                    reminderMinutesBefore = 5
                )
            )
            dao.insertEvent(
                EventEntity(
                    title = "Cardio & Strength Interval",
                    description = "45-minute HIIT workout session",
                    location = "Equinox Gym",
                    startDate = today,
                    endDate = today,
                    startMinutes = 1080, // 06:00 PM
                    endMinutes = 1140,   // 07:00 PM
                    category = "Health & Habits",
                    colorHex = 0xFFF59E0B,
                    reminderMinutesBefore = 30
                )
            )
            dao.insertEvent(
                EventEntity(
                    title = "Global Team Showcase",
                    description = "Demo new calendar features to cross-functional leads",
                    location = "Auditorium A",
                    startDate = tomorrow,
                    endDate = tomorrow,
                    startMinutes = 600, // 10:00 AM
                    endMinutes = 660,   // 11:00 AM
                    category = "Work",
                    colorHex = 0xFF6366F1,
                    reminderMinutesBefore = 30
                )
            )

            // Initial Tasks
            dao.insertTask(
                TaskEntity(
                    title = "Finalize quarterly planning report",
                    description = "Include metrics for team velocity and milestone delivery",
                    dueDate = today,
                    dueMinutes = 1020, // 05:00 PM
                    priority = "HIGH",
                    category = "Work",
                    estimatedMinutes = 60,
                    subtasksJson = """[{"id":1,"title":"Gather analytics charts","isCompleted":true},{"id":2,"title":"Write executive summary","isCompleted":false},{"id":3,"title":"Share with stakeholders","isCompleted":false}]"""
                )
            )
            dao.insertTask(
                TaskEntity(
                    title = "Review pull request #104",
                    description = "Time-block collision detection algorithm",
                    dueDate = today,
                    dueMinutes = 840, // 02:00 PM
                    priority = "URGENT",
                    category = "Work",
                    estimatedMinutes = 25,
                    subtasksJson = "[]"
                )
            )
            dao.insertTask(
                TaskEntity(
                    title = "Read 30 pages of High Output Management",
                    description = "Chapters 4-5 on managerial leverage",
                    dueDate = today,
                    dueMinutes = 1260, // 09:00 PM
                    priority = "LOW",
                    category = "Personal",
                    estimatedMinutes = 40,
                    subtasksJson = "[]"
                )
            )
            dao.insertTask(
                TaskEntity(
                    title = "Prepare keynote slides for product launch",
                    description = "Draft structure and key value propositions",
                    dueDate = tomorrow,
                    dueMinutes = 720,
                    priority = "HIGH",
                    category = "Work",
                    estimatedMinutes = 90,
                    subtasksJson = """[{"id":1,"title":"Outline narrative flow","isCompleted":false},{"id":2,"title":"Create architecture diagram","isCompleted":false}]"""
                )
            )

            // Initial Habits
            dao.insertHabit(
                HabitEntity(
                    title = "Morning Meditation & Clarity",
                    description = "10 minutes mindfulness before opening notifications",
                    category = "Health & Habits",
                    iconName = "self_improvement",
                    colorHex = 0xFF10B981,
                    frequency = "DAILY",
                    targetDaysPerWeek = 7,
                    reminderMinutes = 420 // 7:00 AM
                )
            )
            dao.insertHabit(
                HabitEntity(
                    title = "Hydration: 2.5L Daily",
                    description = "Track optimal fluid intake across the workday",
                    category = "Health & Habits",
                    iconName = "water_drop",
                    colorHex = 0xFF06B6D4,
                    frequency = "DAILY",
                    targetDaysPerWeek = 7,
                    reminderMinutes = 540 // 9:00 AM
                )
            )
            dao.insertHabit(
                HabitEntity(
                    title = "Code / Technical Study",
                    description = "Practice Kotlin Coroutines & Jetpack Compose internals",
                    category = "Deep Work",
                    iconName = "code",
                    colorHex = 0xFF8B5CF6,
                    frequency = "WEEKDAYS",
                    targetDaysPerWeek = 5,
                    reminderMinutes = 1200 // 8:00 PM
                )
            )
            dao.insertHabit(
                HabitEntity(
                    title = "Reading (30 mins)",
                    description = "Consistent non-fiction reading",
                    category = "Personal",
                    iconName = "menu_book",
                    colorHex = 0xFFF59E0B,
                    frequency = "DAILY",
                    targetDaysPerWeek = 7,
                    reminderMinutes = 1260 // 9:00 PM
                )
            )

            // Initial Routines
            dao.insertRoutine(
                RoutineTemplateEntity(
                    name = "Morning Flow Routine",
                    description = "Optimal wake-up cadence for peak cognitive readiness",
                    category = "Health & Habits",
                    iconName = "wb_sunny",
                    itemsJson = """[
                        {"title":"Hydrate & Light Mobility","category":"Health & Habits","offsetMinutes":0,"durationMinutes":20,"colorHex":17457793},
                        {"title":"Mindful Meditation","category":"Health & Habits","offsetMinutes":20,"durationMinutes":15,"colorHex":17457793},
                        {"title":"Review Top 3 Daily Priorities","category":"Work","offsetMinutes":35,"durationMinutes":15,"colorHex":6514417}
                    ]"""
                )
            )
            dao.insertRoutine(
                RoutineTemplateEntity(
                    name = "Deep Focus Sprint",
                    description = "90-minute uninterrupted creative or engineering block",
                    category = "Deep Work",
                    iconName = "psychology",
                    itemsJson = """[
                        {"title":"Async Environment Prep","category":"Deep Work","offsetMinutes":0,"durationMinutes":10,"colorHex":9133302},
                        {"title":"Monolithic Focus Sprint","category":"Deep Work","offsetMinutes":10,"durationMinutes":70,"colorHex":9133302},
                        {"title":"Progress Logging & Buffer","category":"Work","offsetMinutes":80,"durationMinutes":10,"colorHex":6514417}
                    ]"""
                )
            )

            // Initial Goals
            dao.insertGoal(
                GoalEntity(
                    title = "Launch Chronos Executive Suite",
                    description = "Ship the complete intelligent calendar, planner & habit matrix",
                    type = "MONTHLY",
                    targetDate = inTwoDays,
                    progressPercent = 75,
                    category = "Work",
                    milestonesJson = """[{"title":"Core calendar engine","isDone":true},{"title":"Time-blocking planner","isDone":true},{"title":"Habit streak system","isDone":true},{"title":"Real notification manager","isDone":true}]"""
                )
            )
            dao.insertGoal(
                GoalEntity(
                    title = "Read 2 Books this Month",
                    description = "High Output Management & Deep Work",
                    type = "MONTHLY",
                    targetDate = LocalDate.now().plusDays(14).toString(),
                    progressPercent = 50,
                    category = "Personal",
                    milestonesJson = """[{"title":"High Output Management","isDone":true},{"title":"Deep Work by Cal Newport","isDone":false}]"""
                )
            )

            // Initial Notes
            dao.insertNote(
                NoteEntity(
                    title = "Product Strategy Notes",
                    content = "Key principles: Minimalist glassmorphic layout, micro-interactions with haptic feedback, zero unnecessary taps for creating time-blocks.",
                    tags = "Architecture, Strategy, Design",
                    pinned = true
                )
            )
            dao.insertNote(
                NoteEntity(
                    title = "Meeting Insights with Stakeholders",
                    content = "Users value conflict warnings when scheduling overlapping meetings and quick task-to-calendar conversion.",
                    tags = "Feedback, UX",
                    pinned = false
                )
            )
        }
    }
}

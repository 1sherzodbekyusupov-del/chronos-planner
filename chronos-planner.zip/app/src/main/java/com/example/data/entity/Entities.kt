package com.example.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "events",
    indices = [Index(value = ["startDate"]), Index(value = ["category"])]
)
data class EventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val location: String = "",
    val startDate: String, // YYYY-MM-DD
    val endDate: String,   // YYYY-MM-DD
    val startMinutes: Int = 540, // 9:00 AM in minutes from midnight, -1 if all-day
    val endMinutes: Int = 600,   // 10:00 AM
    val isAllDay: Boolean = false,
    val category: String = "Work",
    val colorHex: Long = 0xFF6366F1,
    val recurrenceRule: String = "NONE", // NONE, DAILY, WEEKLY, MONTHLY, YEARLY
    val reminderMinutesBefore: Int = 15,
    val hasMultipleReminders: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tasks",
    indices = [Index(value = ["dueDate"]), Index(value = ["isCompleted"]), Index(value = ["priority"])]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val dueDate: String? = null, // YYYY-MM-DD
    val dueMinutes: Int? = null,
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH, URGENT
    val category: String = "Work",
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val estimatedMinutes: Int = 30,
    val actualMinutes: Int = 0,
    val subtasksJson: String = "[]", // [{"id":1,"title":"item","isCompleted":false}]
    val tags: String = "",
    val isRecurring: Boolean = false,
    val recurrence: String = "NONE",
    val reminderMinutesBefore: Int = 15,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "habits"
)
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String = "Health & Habits",
    val iconName: String = "fitness_center",
    val colorHex: Long = 0xFFF59E0B,
    val frequency: String = "DAILY", // DAILY, WEEKDAYS, WEEKENDS, 3X_WEEK
    val targetDaysPerWeek: Int = 7,
    val reminderMinutes: Int = 480, // 8:00 AM
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "habit_logs",
    indices = [Index(value = ["habitId", "date"], unique = true)]
)
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val habitId: Long,
    val date: String, // YYYY-MM-DD
    val isCompleted: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "routine_templates")
data class RoutineTemplateEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String = "",
    val category: String = "Work",
    val iconName: String = "wb_sunny",
    val itemsJson: String = "[]" // [{"title":"Deep Work","category":"Deep Work","offsetMinutes":0,"durationMinutes":90,"colorHex":996366F1}]
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val type: String = "MONTHLY", // DAILY, WEEKLY, MONTHLY, LONG_TERM
    val targetDate: String, // YYYY-MM-DD
    val progressPercent: Int = 0,
    val category: String = "Work",
    val milestonesJson: String = "[]", // [{"title":"Milestone 1","isDone":false}]
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String = "",
    val tags: String = "",
    val pinned: Boolean = false,
    val linkedEventId: Long? = null,
    val linkedTaskId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

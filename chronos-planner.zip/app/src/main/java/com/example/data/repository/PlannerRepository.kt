package com.example.data.repository

import com.example.data.dao.PlannerDao
import com.example.data.entity.EventEntity
import com.example.data.entity.GoalEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.HabitLogEntity
import com.example.data.entity.NoteEntity
import com.example.data.entity.RoutineTemplateEntity
import com.example.data.entity.TaskEntity
import com.example.receiver.AlarmScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class HabitWithStats(
    val habit: HabitEntity,
    val isCompletedToday: Boolean,
    val currentStreak: Int,
    val bestStreak: Int,
    val completionCountThisWeek: Int,
    val historyDates: Set<String>
)

class PlannerRepository(
    private val dao: PlannerDao,
    private val alarmScheduler: AlarmScheduler
) {
    // Events
    val allEvents: Flow<List<EventEntity>> = dao.getAllEvents()

    fun getEventsForDate(date: String): Flow<List<EventEntity>> = dao.getEventsForDate(date)

    fun getEventsInRange(startDate: String, endDate: String): Flow<List<EventEntity>> =
        dao.getEventsInRange(startDate, endDate)

    suspend fun insertEvent(event: EventEntity): Long {
        val id = dao.insertEvent(event)
        val saved = event.copy(id = id)
        alarmScheduler.scheduleEventReminder(saved)
        return id
    }

    suspend fun updateEvent(event: EventEntity) {
        dao.updateEvent(event)
        alarmScheduler.scheduleEventReminder(event)
    }

    suspend fun deleteEvent(event: EventEntity) {
        alarmScheduler.cancelReminder(event.id)
        dao.deleteEvent(event)
    }

    suspend fun deleteEventById(id: Long) {
        alarmScheduler.cancelReminder(id)
        dao.deleteEventById(id)
    }

    suspend fun duplicateEvent(event: EventEntity): Long {
        val copy = event.copy(
            id = 0,
            title = "${event.title} (Copy)",
            createdAt = System.currentTimeMillis()
        )
        return insertEvent(copy)
    }

    suspend fun findConflicts(
        date: String,
        startMin: Int,
        endMin: Int,
        excludeId: Long? = null
    ): List<EventEntity> {
        val dayEvents = dao.getEventsForDate(date).first()
        return dayEvents.filter { other ->
            if (other.id == excludeId || other.isAllDay) return@filter false
            // Overlap condition: startA < endB and startB < endA
            startMin < other.endMinutes && other.startMinutes < endMin
        }
    }

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()

    fun getTasksForDate(date: String): Flow<List<TaskEntity>> = dao.getTasksForDate(date)

    suspend fun insertTask(task: TaskEntity): Long {
        val id = dao.insertTask(task)
        val saved = task.copy(id = id)
        alarmScheduler.scheduleTaskReminder(saved)
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        dao.updateTask(task)
        alarmScheduler.scheduleTaskReminder(task)
    }

    suspend fun deleteTask(task: TaskEntity) {
        alarmScheduler.cancelReminder(task.id + 100000)
        dao.deleteTask(task)
    }

    suspend fun toggleTaskCompleted(task: TaskEntity) {
        val newStatus = !task.isCompleted
        val updated = task.copy(
            isCompleted = newStatus,
            completedAt = if (newStatus) System.currentTimeMillis() else null
        )
        dao.updateTask(updated)
    }

    suspend fun convertTaskToEvent(task: TaskEntity, date: String, startMin: Int, durationMin: Int = 45): Long {
        val event = EventEntity(
            title = task.title,
            description = task.description,
            startDate = date,
            endDate = date,
            startMinutes = startMin,
            endMinutes = startMin + durationMin,
            category = task.category,
            reminderMinutesBefore = 15
        )
        return insertEvent(event)
    }

    // Habits
    val allHabits: Flow<List<HabitEntity>> = dao.getAllHabits()
    val allHabitLogs: Flow<List<HabitLogEntity>> = dao.getAllHabitLogs()

    suspend fun insertHabit(habit: HabitEntity): Long = dao.insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = dao.updateHabit(habit)
    suspend fun deleteHabit(habit: HabitEntity) = dao.deleteHabit(habit)

    suspend fun toggleHabitForDate(habitId: Long, date: String, isCurrentlyCompleted: Boolean) {
        if (isCurrentlyCompleted) {
            dao.deleteHabitLog(habitId, date)
        } else {
            dao.insertHabitLog(HabitLogEntity(habitId = habitId, date = date))
        }
    }

    // Routines
    val allRoutines: Flow<List<RoutineTemplateEntity>> = dao.getAllRoutines()
    suspend fun insertRoutine(routine: RoutineTemplateEntity): Long = dao.insertRoutine(routine)
    suspend fun updateRoutine(routine: RoutineTemplateEntity) = dao.updateRoutine(routine)
    suspend fun deleteRoutine(routine: RoutineTemplateEntity) = dao.deleteRoutine(routine)

    suspend fun applyRoutineToDate(
        routine: RoutineTemplateEntity,
        targetDate: String,
        baseStartMinutes: Int = 480, // 08:00 AM
        conflictStrategy: String = "KEEP_ALL" // "KEEP_ALL", "REPLACE_CONFLICTS"
    ): Int {
        var addedCount = 0
        try {
            val jsonArray = JSONArray(routine.itemsJson)
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                val title = item.getString("title")
                val category = item.optString("category", routine.category)
                val offset = item.optInt("offsetMinutes", 0)
                val duration = item.optInt("durationMinutes", 30)
                val colorHex = item.optLong("colorHex", 0xFF6366F1)

                val itemStart = baseStartMinutes + offset
                val itemEnd = itemStart + duration

                if (conflictStrategy == "REPLACE_CONFLICTS") {
                    val conflicts = findConflicts(targetDate, itemStart, itemEnd)
                    conflicts.forEach { dao.deleteEvent(it) }
                }

                val event = EventEntity(
                    title = title,
                    description = "Applied from routine: ${routine.name}",
                    startDate = targetDate,
                    endDate = targetDate,
                    startMinutes = itemStart,
                    endMinutes = itemEnd,
                    category = category,
                    colorHex = colorHex,
                    reminderMinutesBefore = 10
                )
                insertEvent(event)
                addedCount++
            }
        } catch (_: Exception) {}
        return addedCount
    }

    // Goals
    val allGoals: Flow<List<GoalEntity>> = dao.getAllGoals()
    suspend fun insertGoal(goal: GoalEntity): Long = dao.insertGoal(goal)
    suspend fun updateGoal(goal: GoalEntity) = dao.updateGoal(goal)
    suspend fun deleteGoal(goal: GoalEntity) = dao.deleteGoal(goal)

    // Notes
    val allNotes: Flow<List<NoteEntity>> = dao.getAllNotes()
    suspend fun insertNote(note: NoteEntity): Long = dao.insertNote(note)
    suspend fun updateNote(note: NoteEntity) = dao.updateNote(note)
    suspend fun deleteNote(note: NoteEntity) = dao.deleteNote(note)

    // Global Search
    fun searchAll(query: String): SearchResultsFlow {
        return SearchResultsFlow(
            events = dao.searchEvents(query),
            tasks = dao.searchTasks(query),
            notes = dao.searchNotes(query)
        )
    }

    // Export JSON Backup
    suspend fun exportDataJson(): String {
        val root = JSONObject()
        val events = dao.getAllEvents().first()
        val tasks = dao.getAllTasks().first()
        val habits = dao.getAllHabits().first()
        val routines = dao.getAllRoutines().first()
        val goals = dao.getAllGoals().first()
        val notes = dao.getAllNotes().first()

        val eventsArray = JSONArray()
        events.forEach { e ->
            eventsArray.put(JSONObject().apply {
                put("title", e.title)
                put("description", e.description)
                put("location", e.location)
                put("startDate", e.startDate)
                put("endDate", e.endDate)
                put("startMinutes", e.startMinutes)
                put("endMinutes", e.endMinutes)
                put("category", e.category)
            })
        }
        root.put("events", eventsArray)

        val tasksArray = JSONArray()
        tasks.forEach { t ->
            tasksArray.put(JSONObject().apply {
                put("title", t.title)
                put("priority", t.priority)
                put("category", t.category)
                put("dueDate", t.dueDate ?: "")
                put("isCompleted", t.isCompleted)
            })
        }
        root.put("tasks", tasksArray)
        root.put("habitsCount", habits.size)
        root.put("routinesCount", routines.size)
        root.put("goalsCount", goals.size)
        root.put("notesCount", notes.size)
        root.put("exportedAt", System.currentTimeMillis())

        return root.toString(2)
    }
}

data class SearchResultsFlow(
    val events: Flow<List<EventEntity>>,
    val tasks: Flow<List<TaskEntity>>,
    val notes: Flow<List<NoteEntity>>
)

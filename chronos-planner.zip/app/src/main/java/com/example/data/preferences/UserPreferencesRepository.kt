package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "chronos_settings")

data class UserPreferences(
    val language: String = "en", // "en" or "uz"
    val is24HourFormat: Boolean = false,
    val firstDayIsMonday: Boolean = true,
    val defaultCalendarView: String = "MONTH", // DAY, WEEK, MONTH, AGENDA
    val isDarkTheme: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val notificationSound: Boolean = true,
    val notificationVibrate: Boolean = true,
    val defaultReminderMinutes: Int = 15,
    val workDayStartHour: Int = 9,
    val workDayEndHour: Int = 18
)

class UserPreferencesRepository(private val context: Context) {
    companion object {
        val KEY_LANGUAGE = stringPreferencesKey("language")
        val KEY_24_HOUR = booleanPreferencesKey("is_24_hour")
        val KEY_FIRST_DAY_MONDAY = booleanPreferencesKey("first_day_monday")
        val KEY_DEFAULT_CALENDAR_VIEW = stringPreferencesKey("default_calendar_view")
        val KEY_DARK_THEME = booleanPreferencesKey("is_dark_theme")
        val KEY_NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val KEY_NOTIFICATION_SOUND = booleanPreferencesKey("notification_sound")
        val KEY_NOTIFICATION_VIBRATE = booleanPreferencesKey("notification_vibrate")
        val KEY_DEFAULT_REMINDER = intPreferencesKey("default_reminder_minutes")
        val KEY_WORK_START = intPreferencesKey("work_start_hour")
        val KEY_WORK_END = intPreferencesKey("work_end_hour")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            language = prefs[KEY_LANGUAGE] ?: "en",
            is24HourFormat = prefs[KEY_24_HOUR] ?: false,
            firstDayIsMonday = prefs[KEY_FIRST_DAY_MONDAY] ?: true,
            defaultCalendarView = prefs[KEY_DEFAULT_CALENDAR_VIEW] ?: "MONTH",
            isDarkTheme = prefs[KEY_DARK_THEME] ?: true,
            notificationsEnabled = prefs[KEY_NOTIFICATIONS_ENABLED] ?: true,
            notificationSound = prefs[KEY_NOTIFICATION_SOUND] ?: true,
            notificationVibrate = prefs[KEY_NOTIFICATION_VIBRATE] ?: true,
            defaultReminderMinutes = prefs[KEY_DEFAULT_REMINDER] ?: 15,
            workDayStartHour = prefs[KEY_WORK_START] ?: 9,
            workDayEndHour = prefs[KEY_WORK_END] ?: 18
        )
    }

    suspend fun updateLanguage(lang: String) {
        context.dataStore.edit { it[KEY_LANGUAGE] = lang }
    }

    suspend fun updateTimeFormat(is24Hour: Boolean) {
        context.dataStore.edit { it[KEY_24_HOUR] = is24Hour }
    }

    suspend fun updateFirstDayIsMonday(isMonday: Boolean) {
        context.dataStore.edit { it[KEY_FIRST_DAY_MONDAY] = isMonday }
    }

    suspend fun updateDefaultCalendarView(view: String) {
        context.dataStore.edit { it[KEY_DEFAULT_CALENDAR_VIEW] = view }
    }

    suspend fun updateDarkTheme(isDark: Boolean) {
        context.dataStore.edit { it[KEY_DARK_THEME] = isDark }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun updateNotificationSound(enabled: Boolean) {
        context.dataStore.edit { it[KEY_NOTIFICATION_SOUND] = enabled }
    }

    suspend fun updateNotificationVibrate(enabled: Boolean) {
        context.dataStore.edit { it[KEY_NOTIFICATION_VIBRATE] = enabled }
    }

    suspend fun updateDefaultReminder(minutes: Int) {
        context.dataStore.edit { it[KEY_DEFAULT_REMINDER] = minutes }
    }

    suspend fun updateWorkingHours(startHour: Int, endHour: Int) {
        context.dataStore.edit {
            it[KEY_WORK_START] = startHour
            it[KEY_WORK_END] = endHour
        }
    }
}
